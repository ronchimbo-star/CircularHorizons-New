import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // "admin" or "user"
});

export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  service: text("service"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  author: text("author").notNull().default("Admin"),
  featuredImage: text("featured_image"),
  imageAlt: text("image_alt"),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  seoKeywords: text("seo_keywords"),
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  metaKeywords: text("meta_keywords"),
  tags: text("tags").array().default([]),
  category: text("category").default("General"),
  published: boolean("published").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const pageContent = pgTable("page_content", {
  id: serial("id").primaryKey(),
  page: text("page").notNull().unique(), // "home", "about", "careers", etc.
  title: text("title").notNull(),
  content: text("content").notNull(),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  seoKeywords: text("seo_keywords"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
});

export const insertContactSubmissionSchema = createInsertSchema(contactSubmissions).pick({
  name: true,
  email: true,
  company: true,
  service: true,
  message: true,
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).pick({
  title: true,
  slug: true,
  content: true,
  excerpt: true,
  author: true,
  featuredImage: true,
  imageAlt: true,
  seoTitle: true,
  seoDescription: true,
  seoKeywords: true,
  metaTitle: true,
  metaDescription: true,
  metaKeywords: true,
  tags: true,
  category: true,
  published: true,
});

export const insertPageContentSchema = createInsertSchema(pageContent).pick({
  page: true,
  title: true,
  content: true,
  seoTitle: true,
  seoDescription: true,
  seoKeywords: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = z.infer<typeof insertContactSubmissionSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type PageContent = typeof pageContent.$inferSelect;
export type InsertPageContent = z.infer<typeof insertPageContentSchema>;

// Site Settings
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).unique().notNull(),
  value: text("value"),
  type: varchar("type", { length: 50 }).notNull().default("text"), // text, image, boolean, json
  category: varchar("category", { length: 50 }).notNull().default("general"),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSiteSettingSchema = createInsertSchema(siteSettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertSiteSetting = z.infer<typeof insertSiteSettingSchema>;
export type SiteSetting = typeof siteSettings.$inferSelect;

// Homepage Sections
export const homepageSections = pgTable("homepage_sections", {
  id: serial("id").primaryKey(),
  sectionName: varchar("section_name", { length: 100 }).unique().notNull(), // "hero", "consultancy", "green-registry", etc.
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  description: text("description"),
  backgroundImage: text("background_image"),
  backgroundColor: varchar("background_color", { length: 50 }).default("#f9fafb"),
  textColor: varchar("text_color", { length: 50 }).default("#111827"),
  overlayText: text("overlay_text"),
  buttonText: text("button_text"),
  buttonLink: text("button_link"),
  icon: text("icon"), // lucide icon name
  iconImage: text("icon_image"), // URL to custom icon image
  iconSize: integer("icon_size").default(24), // Size in pixels
  isVisible: boolean("is_visible").default(true),
  sortOrder: integer("sort_order").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const sectionCards = pgTable("section_cards", {
  id: serial("id").primaryKey(),
  sectionId: integer("section_id").references(() => homepageSections.id),
  title: text("title").notNull(),
  description: text("description"),
  icon: text("icon"), // lucide icon name
  iconImage: text("icon_image"), // URL to custom icon image
  iconSize: integer("icon_size").default(24), // Size in pixels
  image: text("image"),
  link: text("link"),
  buttonText: text("button_text"),
  sortOrder: integer("sort_order").default(0),
  isVisible: boolean("is_visible").default(true),
});

export const insertHomepageSectionSchema = createInsertSchema(homepageSections).omit({
  id: true,
  updatedAt: true,
});

export const insertSectionCardSchema = createInsertSchema(sectionCards).omit({
  id: true,
});

// About page elements
export const aboutFounder = pgTable("about_founder", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  bio: text("bio").notNull(),
  image: text("image"),
  linkedinUrl: text("linkedin_url"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const aboutTeam = pgTable("about_team", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  bio: text("bio"),
  image: text("image"),
  linkedinUrl: text("linkedin_url"),
  order: integer("order").default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const aboutValues = pgTable("about_values", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon"),
  iconImage: text("icon_image"),
  iconSize: integer("icon_size").default(32),
  order: integer("order").default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAboutFounderSchema = createInsertSchema(aboutFounder).omit({
  id: true,
  updatedAt: true,
});

export const insertAboutTeamSchema = createInsertSchema(aboutTeam).omit({
  id: true,
  updatedAt: true,
});

export const insertAboutValuesSchema = createInsertSchema(aboutValues).omit({
  id: true,
  updatedAt: true,
});

export type InsertHomepageSection = z.infer<typeof insertHomepageSectionSchema>;
export type HomepageSection = typeof homepageSections.$inferSelect;
export type InsertSectionCard = z.infer<typeof insertSectionCardSchema>;
export type SectionCard = typeof sectionCards.$inferSelect;
export type AboutFounder = typeof aboutFounder.$inferSelect;
export type InsertAboutFounder = z.infer<typeof insertAboutFounderSchema>;
export type AboutTeam = typeof aboutTeam.$inferSelect;
export type InsertAboutTeam = z.infer<typeof insertAboutTeamSchema>;
export const aboutSections = pgTable("about_sections", {
  id: serial("id").primaryKey(),
  sectionKey: varchar("section_key", { length: 255 }).unique().notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  displayOrder: integer("display_order").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAboutSectionSchema = createInsertSchema(aboutSections).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type AboutValues = typeof aboutValues.$inferSelect;
export type InsertAboutValues = z.infer<typeof insertAboutValuesSchema>;
export type AboutSection = typeof aboutSections.$inferSelect;
export type InsertAboutSection = z.infer<typeof insertAboutSectionSchema>;
