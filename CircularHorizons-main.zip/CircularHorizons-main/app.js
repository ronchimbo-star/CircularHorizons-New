// Hostinger-specific entry point
// This file should be set as the startup file in Hostinger Node.js selector

// Import the built application
import('./dist/index.js').catch(console.error);