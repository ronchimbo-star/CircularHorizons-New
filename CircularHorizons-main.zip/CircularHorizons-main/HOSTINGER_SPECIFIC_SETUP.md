# Hostinger-Specific Setup Instructions

## Immediate Fix for "Not Found" Error

Your circularhorizons.com is showing "not found" because Hostinger requires specific configuration for Node.js applications.

### Step 1: Upload Additional Files
Upload these new files to your Hostinger public_html directory:
- `app.js` (Hostinger entry point)
- `.htaccess` (Routing configuration)

### Step 2: Configure Node.js in Hostinger Panel

1. **Go to Hostinger Control Panel**
   - Navigate to "Advanced" → "Node.js Selector"
   - Select your domain: circularhorizons.com

2. **Node.js Configuration**
   - **Node.js Version**: 18.x or 20.x
   - **Startup File**: `app.js` (NOT dist/index.js)
   - **Application Root**: `/public_html` (default)
   - **Application URL**: `/` (default)

3. **Environment Variables**
   Add these in the Node.js Selector:
   ```
   NODE_ENV=production
   PORT=3000
   DATABASE_URL=your-postgresql-connection-string
   EMAIL_USER=ronchimbo@gmail.com
   EMAIL_PASS=your-gmail-app-password
   SESSION_SECRET=your-secure-random-string
   ```

### Step 3: Install Dependencies
In Hostinger control panel:
1. Go to "Node.js Selector"
2. Click "NPM Install" button
3. Wait for installation to complete

### Step 4: Database Setup
1. **Create PostgreSQL Database**
   - Go to "Databases" in Hostinger panel
   - Create new PostgreSQL database
   - Note connection details

2. **Set DATABASE_URL**
   Format: `postgresql://username:password@hostname:port/database_name`

3. **Run Migration**
   In terminal/SSH:
   ```bash
   cd public_html
   npm run db:push
   ```

### Step 5: Start Application
1. In Node.js Selector, click "Restart"
2. Check that status shows "Running"
3. Test: visit circularhorizons.com

## File Structure Check

Your public_html should contain:
```
public_html/
├── app.js                # NEW: Hostinger entry point
├── .htaccess            # NEW: Routing configuration
├── dist/
│   ├── index.js         # Built server
│   └── public/          # Frontend assets
├── package.json
├── package-lock.json
├── node_modules/        # After npm install
├── drizzle.config.ts
└── .env.example
```

## Testing Steps

1. **Test Node.js Status**
   - Check Node.js Selector shows "Running"
   - Look for any error messages

2. **Test Database**
   ```bash
   npm run db:push
   ```
   Should show "No schema changes detected"

3. **Test Website**
   - Visit circularhorizons.com
   - Should load homepage
   - Try circularhorizons.com/admin/login

## Common Hostinger Issues

### Issue: "Application failed to start"
- Check startup file is set to `app.js`
- Verify all environment variables are set
- Check error logs in Node.js Selector

### Issue: "Database connection failed"
- Verify PostgreSQL database exists
- Check DATABASE_URL format
- Ensure database user has proper permissions

### Issue: "Static files not loading"
- Check .htaccess file is uploaded
- Verify dist/public/ directory exists
- Check file permissions

## Alternative: Manual Process

If Node.js Selector doesn't work, try SSH method:

1. **SSH into your server**
2. **Navigate to project**
   ```bash
   cd public_html
   ```
3. **Install dependencies**
   ```bash
   npm install
   ```
4. **Run database migration**
   ```bash
   npm run db:push
   ```
5. **Start application**
   ```bash
   npm start
   ```

## Success Indicators

Your deployment is working when:
- circularhorizons.com loads without errors
- Admin panel accessible at circularhorizons.com/admin
- Contact form sends emails
- All pages load correctly

## Need Help?

If you're still getting "not found":
1. Check Hostinger error logs
2. Verify Node.js is running in control panel
3. Ensure all files are uploaded correctly
4. Contact Hostinger support if needed

The key issue is usually the startup file configuration - make sure it's set to `app.js` in the Node.js Selector.