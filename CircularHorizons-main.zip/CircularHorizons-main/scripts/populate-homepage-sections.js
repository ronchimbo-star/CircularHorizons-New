import { db } from "../server/db.ts";
import { homepageSections, sectionCards } from "../shared/schema.ts";

const defaultSections = [
  {
    sectionName: "hero",
    title: "Transform Your Business into a Sustainability Leader",
    subtitle: "Expert ESG solutions for the circular economy",
    description: "Join the sustainable revolution with our comprehensive ESG reporting and circular economy consulting services. We help businesses reduce environmental impact while maximizing profitability.",
    backgroundImage: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80",
    overlayText: "Building a Sustainable Future Together",
    buttonText: "Start Your Journey",
    buttonLink: "/contact",
    icon: "Globe",
    isVisible: true,
    sortOrder: 0,
  },
  {
    sectionName: "consultancy",
    title: "Circular Horizons Consultancy",
    subtitle: "Strategic sustainability consulting for modern businesses",
    description: "Our expert consultants help organizations transition to circular economy models through strategic planning, implementation support, and performance measurement.",
    icon: "Recycle",
    isVisible: true,
    sortOrder: 1,
  },
  {
    sectionName: "green-registry",
    title: "Green Registry",
    subtitle: "Verify and showcase your sustainability credentials",
    description: "Register your sustainable practices and get certified. Our green registry helps businesses demonstrate their commitment to environmental responsibility.",
    icon: "Leaf",
    isVisible: true,
    sortOrder: 2,
  },
  {
    sectionName: "esg-report",
    title: "ESG Reporting",
    subtitle: "Comprehensive ESG reporting and analysis",
    description: "Transform your sustainability data into actionable insights with our advanced ESG reporting platform. Meet compliance requirements and drive strategic decision-making.",
    icon: "BarChart3",
    isVisible: true,
    sortOrder: 3,
  },
  {
    sectionName: "mizan-esg",
    title: "Mizan ESG",
    subtitle: "Advanced ESG assessment and benchmarking",
    description: "Our Mizan ESG platform provides comprehensive assessment tools and industry benchmarking to help you measure and improve your sustainability performance.",
    icon: "TrendingUp",
    isVisible: true,
    sortOrder: 4,
  },
  {
    sectionName: "waste-institute",
    title: "Waste Institute",
    subtitle: "Educational platform for waste management professionals",
    description: "Access cutting-edge research, training programs, and resources for waste management professionals. Learn from industry experts and stay ahead of regulatory changes.",
    icon: "Users",
    isVisible: true,
    sortOrder: 5,
  },
];

const consultancyCards = [
  {
    title: "Circular Strategy Development",
    description: "Design comprehensive circular economy strategies tailored to your business model and industry requirements.",
    icon: "Target",
    link: "/contact",
    buttonText: "Learn More",
    sortOrder: 0,
    isVisible: true,
  },
  {
    title: "Implementation Support",
    description: "Get hands-on support throughout your sustainability transformation journey with our expert implementation teams.",
    icon: "CheckCircle",
    link: "/contact",
    buttonText: "Get Started",
    sortOrder: 1,
    isVisible: true,
  },
  {
    title: "Performance Measurement",
    description: "Track and measure your sustainability progress with our comprehensive monitoring and reporting frameworks.",
    icon: "BarChart3",
    link: "/contact",
    buttonText: "Measure Impact",
    sortOrder: 2,
    isVisible: true,
  },
];

const greenRegistryCards = [
  {
    title: "Certification Programs",
    description: "Achieve recognized sustainability certifications that demonstrate your commitment to environmental responsibility.",
    icon: "Award",
    link: "/contact",
    buttonText: "Get Certified",
    sortOrder: 0,
    isVisible: true,
  },
  {
    title: "Verification Services",
    description: "Independent verification of your sustainability claims and practices by our certified experts.",
    icon: "Shield",
    link: "/contact",
    buttonText: "Verify Now",
    sortOrder: 1,
    isVisible: true,
  },
  {
    title: "Registry Platform",
    description: "Showcase your verified sustainable practices on our public registry platform for maximum visibility.",
    icon: "Globe",
    link: "/contact",
    buttonText: "Register",
    sortOrder: 2,
    isVisible: true,
  },
];

const esgReportCards = [
  {
    title: "Automated Data Collection",
    description: "Streamline your ESG data collection with our automated systems that integrate with your existing workflows.",
    icon: "Zap",
    link: "/contact",
    buttonText: "Automate",
    sortOrder: 0,
    isVisible: true,
  },
  {
    title: "Regulatory Compliance",
    description: "Ensure full compliance with evolving ESG regulations and reporting requirements across all jurisdictions.",
    icon: "CheckCircle",
    link: "/contact",
    buttonText: "Comply",
    sortOrder: 1,
    isVisible: true,
  },
  {
    title: "Stakeholder Reporting",
    description: "Create compelling ESG reports that communicate your sustainability story to investors and stakeholders.",
    icon: "Users",
    link: "/contact",
    buttonText: "Report",
    sortOrder: 2,
    isVisible: true,
  },
];

async function populateHomepageSections() {
  try {
    console.log("Populating homepage sections...");
    
    // Insert sections
    const insertedSections = await db.insert(homepageSections).values(defaultSections).returning();
    console.log(`Inserted ${insertedSections.length} sections`);

    // Find section IDs
    const consultancySection = insertedSections.find(s => s.sectionName === "consultancy");
    const greenRegistrySection = insertedSections.find(s => s.sectionName === "green-registry");
    const esgReportSection = insertedSections.find(s => s.sectionName === "esg-report");

    // Insert cards for consultancy section
    if (consultancySection) {
      const consultancyCardsWithSection = consultancyCards.map(card => ({
        ...card,
        sectionId: consultancySection.id,
      }));
      await db.insert(sectionCards).values(consultancyCardsWithSection);
      console.log(`Inserted ${consultancyCardsWithSection.length} cards for consultancy section`);
    }

    // Insert cards for green registry section
    if (greenRegistrySection) {
      const greenRegistryCardsWithSection = greenRegistryCards.map(card => ({
        ...card,
        sectionId: greenRegistrySection.id,
      }));
      await db.insert(sectionCards).values(greenRegistryCardsWithSection);
      console.log(`Inserted ${greenRegistryCardsWithSection.length} cards for green registry section`);
    }

    // Insert cards for ESG report section
    if (esgReportSection) {
      const esgReportCardsWithSection = esgReportCards.map(card => ({
        ...card,
        sectionId: esgReportSection.id,
      }));
      await db.insert(sectionCards).values(esgReportCardsWithSection);
      console.log(`Inserted ${esgReportCardsWithSection.length} cards for ESG report section`);
    }

    console.log("Homepage sections populated successfully!");
  } catch (error) {
    console.error("Error populating homepage sections:", error);
  }
}

populateHomepageSections();