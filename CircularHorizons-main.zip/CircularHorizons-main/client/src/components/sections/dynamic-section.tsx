import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import * as Icons from "lucide-react";
import type { HomepageSection, SectionCard } from "@shared/schema";

interface DynamicSectionProps {
  sectionName: string;
  fallbackComponent?: React.ComponentType;
}

export default function DynamicSection({ sectionName, fallbackComponent: FallbackComponent }: DynamicSectionProps) {
  const { data: section, isLoading } = useQuery({
    queryKey: ["/api/homepage-sections", sectionName],
    queryFn: async () => {
      const response = await fetch(`/api/homepage-sections/${sectionName}`);
      if (!response.ok) {
        if (response.status === 404) {
          return null;
        }
        throw new Error("Failed to fetch section");
      }
      return response.json();
    },
  });

  const { data: cards } = useQuery({
    queryKey: ["/api/section-cards", section?.id],
    queryFn: async () => {
      if (!section?.id) return [];
      const response = await fetch(`/api/section-cards/${section.id}`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!section?.id,
  });

  // If loading or no section found, show fallback component
  if (isLoading || !section) {
    return FallbackComponent ? <FallbackComponent /> : null;
  }

  // If section is not visible, don't render anything
  if (!section.isVisible) {
    return null;
  }

  // Get the icon component or use custom image
  const IconComponent = section.icon ? (Icons as any)[section.icon] : null;
  const iconSize = section.iconSize || 24;

  // Hero section with background image
  if (section.sectionName === "hero") {
    return (
      <section className="relative min-h-screen flex items-center justify-center" id={sectionName}>
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${section.backgroundImage})` }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        </div>
        
        {/* Content */}
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {(IconComponent || section.iconImage) && (
            <div className="mx-auto flex items-center justify-center mb-8">
              {section.iconImage ? (
                <img
                  src={section.iconImage}
                  alt={`${section.title} icon`}
                  className="object-contain"
                  style={{ width: iconSize + 'px', height: iconSize + 'px' }}
                />
              ) : IconComponent ? (
                <div className="flex items-center justify-center h-20 w-20 rounded-full bg-primary text-white">
                  <IconComponent style={{ width: iconSize + 'px', height: iconSize + 'px' }} />
                </div>
              ) : null}
            </div>
          )}
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            {section.title}
          </h1>
          {section.subtitle && (
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              {section.subtitle}
            </p>
          )}
          {section.description && (
            <p className="text-lg mb-10 text-gray-300 max-w-2xl mx-auto">
              {section.description}
            </p>
          )}
          {section.buttonText && section.buttonLink && (
            <Link href={section.buttonLink}>
              <Button className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg">
                {section.buttonText}
              </Button>
            </Link>
          )}
        </div>
      </section>
    );
  }

  // Regular sections
  return (
    <section 
      className="py-16" 
      id={sectionName}
      style={{
        backgroundColor: section.backgroundColor || "#f9fafb",
        color: section.textColor || "#111827"
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          {(IconComponent || section.iconImage) && (
            <div className="mx-auto flex items-center justify-center mb-6">
              {section.iconImage ? (
                <img
                  src={section.iconImage}
                  alt={`${section.title} icon`}
                  className="object-contain"
                  style={{ width: iconSize + 'px', height: iconSize + 'px' }}
                />
              ) : IconComponent ? (
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                  <IconComponent style={{ width: iconSize + 'px', height: iconSize + 'px' }} />
                </div>
              ) : null}
            </div>
          )}
          <h2 className="text-3xl font-extrabold sm:text-4xl mb-4" style={{ color: section.textColor || "#111827" }}>
            {section.title}
          </h2>
          {section.subtitle && (
            <p className="text-xl mb-6 opacity-80" style={{ color: section.textColor || "#111827" }}>
              {section.subtitle}
            </p>
          )}
          {section.description && (
            <p className="text-lg max-w-3xl mx-auto opacity-70" style={{ color: section.textColor || "#111827" }}>
              {section.description}
            </p>
          )}
        </div>

        {/* Cards Grid */}
        {cards && cards.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {cards
              .filter((card: SectionCard) => card.isVisible)
              .sort((a: SectionCard, b: SectionCard) => a.sortOrder - b.sortOrder)
              .map((card: SectionCard) => {
                const CardIcon = card.icon ? (Icons as any)[card.icon] : null;
                const cardIconSize = card.iconSize || 28; // Default to 28px for cards
                
                return (
                  <div key={card.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 border border-gray-100">
                    {/* Card Image */}
                    {card.image && (
                      <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${card.image})` }} />
                    )}
                    
                    <div className="p-8 text-center">
                      {/* Card Icon */}
                      {(CardIcon || card.iconImage) && (
                        <div className="flex items-center justify-center mb-6">
                          {card.iconImage ? (
                            <img
                              src={card.iconImage}
                              alt={`${card.title} icon`}
                              className="object-contain"
                              style={{ width: cardIconSize + 'px', height: cardIconSize + 'px' }}
                            />
                          ) : CardIcon ? (
                            <div className="flex items-center justify-center h-14 w-14 rounded-full bg-primary text-white">
                              <CardIcon style={{ width: cardIconSize + 'px', height: cardIconSize + 'px' }} />
                            </div>
                          ) : null}
                        </div>
                      )}
                      
                      {/* Card Title */}
                      <h3 className="text-xl font-bold text-gray-900 mb-4">
                        {card.title}
                      </h3>
                      
                      {/* Card Description */}
                      {card.description && (
                        <p className="text-gray-600 mb-6 leading-relaxed">
                          {card.description}
                        </p>
                      )}
                      
                      {/* Card Button */}
                      {card.buttonText && card.link && (
                        <Link href={card.link}>
                          <Button className="w-full bg-primary hover:bg-primary/90 text-white py-3 rounded-lg font-semibold transition-colors duration-200">
                            {card.buttonText}
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        )}

        {/* Section Button */}
        {section.buttonText && section.buttonLink && !section.backgroundImage && (
          <div className="text-center mt-12">
            <Link href={section.buttonLink}>
              <Button className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg rounded-lg font-semibold">
                {section.buttonText}
              </Button>
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}