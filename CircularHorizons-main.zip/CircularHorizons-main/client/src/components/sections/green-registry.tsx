import { Link } from "wouter";
import { TreePine, CheckCircle2, BarChart3, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function GreenRegistry() {
  return (
    <section id="green-registry" className="platform-section green-registry-bg bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
              <img
                className="w-full rounded-lg"
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1415&q=80"
                alt="Green Registry Platform"
              />
            </div>
          </div>
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-primary p-2 rounded-lg">
                <TreePine className="h-8 w-8 text-white" />
              </div>
              <h2 className="ml-3 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                Green Registry
              </h2>
            </div>
            <p className="mt-3 text-lg text-gray-600 sm:mt-5">
              A comprehensive platform for tracking and managing sustainable business practices, certifications, and environmental impact across your organization.
            </p>
            <div className="mt-8">
              <div className="grid grid-cols-1 gap-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <CheckCircle2 className="h-6 w-6 text-primary" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-gray-900">Certification Management</h3>
                    <p className="mt-1 text-gray-600">Track and manage all your sustainability certifications in one place</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-gray-900">Impact Measurement</h3>
                    <p className="mt-1 text-gray-600">Quantify and visualize your environmental impact and improvements</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-gray-900">Stakeholder Engagement</h3>
                    <p className="mt-1 text-gray-600">Connect with suppliers, customers, and partners on sustainability initiatives</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 sm:flex sm:justify-center lg:justify-start">
              <div className="rounded-md shadow">
                <a href="https://www.greenregistry.org" target="_blank" rel="noopener noreferrer">
                  <Button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-primary/90 md:py-4 md:text-lg md:px-10">
                    Explore Green Registry
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
