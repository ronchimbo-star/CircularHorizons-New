import { Link } from "wouter";
import { FileText, Bot, PieChart, Award, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ESGReport() {
  return (
    <section id="esg-report" className="platform-section esg-report-bg bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-primary p-2 rounded-lg">
                <FileText className="h-8 w-8 text-white" />
              </div>
              <h2 className="ml-3 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                ESG Reporting
              </h2>
            </div>
            <p className="mt-3 text-lg text-gray-600 sm:mt-5">
              Streamline your Environmental, Social, and Governance reporting with our comprehensive platform designed for modern sustainability requirements.
            </p>
            <div className="mt-8">
              <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-8">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <Bot className="h-6 w-6 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">AI-Powered Reporting</h3>
                  <p className="mt-1 text-gray-600">Automated data collection and report generation</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <PieChart className="h-6 w-6 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Real-Time Analytics</h3>
                  <p className="mt-1 text-gray-600">Live dashboards and performance tracking</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <Award className="h-6 w-6 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Building Certifications</h3>
                  <p className="mt-1 text-gray-600">Support for green building standards</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <Shield className="h-6 w-6 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Compliance Management</h3>
                  <p className="mt-1 text-gray-600">Ensure regulatory compliance across frameworks</p>
                </div>
              </div>
            </div>
            <div className="mt-8 sm:flex sm:justify-center lg:justify-start">
              <div className="rounded-md shadow">
                <a href="https://www.esgreport.co.uk" target="_blank" rel="noopener noreferrer">
                  <Button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-primary/90 md:py-4 md:text-lg md:px-10">
                    Start ESG Reporting
                  </Button>
                </a>
              </div>
            </div>
          </div>
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
              <img
                className="w-full rounded-lg"
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="ESG Reporting Dashboard"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
