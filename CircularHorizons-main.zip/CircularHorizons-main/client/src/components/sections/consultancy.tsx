import { Link } from "wouter";
import { HandHeart, Lightbulb, TrendingUp, Recycle, Award } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Consultancy() {
  return (
    <section id="consultancy" className="platform-section consultancy-bg bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-primary p-2 rounded-lg">
                <HandHeart className="h-8 w-8 text-white" />
              </div>
              <h2 className="ml-3 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                Circular Horizons Consultancy
              </h2>
            </div>
            <p className="mt-3 text-lg text-gray-600 sm:mt-5">
              Our expert consultants help organizations transition to circular economy models through strategic planning, implementation support, and performance measurement.
            </p>
            <div className="mt-8 sm:max-w-lg sm:mx-auto lg:mx-0">
              <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-8">
                <div className="bg-white p-4 rounded-lg shadow">
                  <Lightbulb className="h-8 w-8 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Circular Strategy</h3>
                  <p className="mt-1 text-gray-600">Develop comprehensive circular economy roadmaps</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <TrendingUp className="h-8 w-8 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">ESG Integration</h3>
                  <p className="mt-1 text-gray-600">Embed sustainability into core business operations</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <Recycle className="h-8 w-8 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Resource Efficiency</h3>
                  <p className="mt-1 text-gray-600">Optimize material flows and reduce waste</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <Award className="h-8 w-8 text-primary mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Certification Support</h3>
                  <p className="mt-1 text-gray-600">Guide through B Corp, ISO and other certifications</p>
                </div>
              </div>
            </div>
            <div className="mt-8 sm:flex sm:justify-center lg:justify-start">
              <div className="rounded-md shadow">
                <Link href="/contact">
                  <Button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-primary/90 md:py-4 md:text-lg md:px-10">
                    Learn More About Our Consultancy
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
              <div className="relative block w-full bg-white rounded-lg overflow-hidden">
                <img
                  className="w-full"
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                  alt="Consultancy services"
                />
                <div className="absolute inset-0 bg-primary opacity-20"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white p-4 rounded-lg shadow-xl text-center">
                    <h3 className="text-lg font-medium text-gray-900">Case Study</h3>
                    <p className="mt-1 text-gray-600">Helped a manufacturing client achieve 40% waste reduction and £1.2M annual savings</p>
                    <Link href="/contact">
                      <Button className="mt-2 inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90">
                        Read Case Study
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
