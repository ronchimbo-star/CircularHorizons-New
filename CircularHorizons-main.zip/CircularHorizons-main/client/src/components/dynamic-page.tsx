import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";

interface DynamicPageProps {
  pageName: string;
  className?: string;
}

export default function DynamicPage({ pageName, className = "" }: DynamicPageProps) {
  const { data: pageContent, isLoading, error } = useQuery({
    queryKey: ["/api/page-content", pageName],
    queryFn: async () => {
      const response = await fetch(`/api/page-content/${pageName}`);
      if (!response.ok) {
        if (response.status === 404) {
          return null;
        }
        throw new Error("Failed to fetch page content");
      }
      return response.json();
    },
  });

  // Set page title and SEO metadata
  useEffect(() => {
    if (pageContent) {
      document.title = pageContent.seoTitle || pageContent.title || "Circular Horizons";
      
      // Update meta description
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', pageContent.seoDescription || '');
      } else {
        const meta = document.createElement('meta');
        meta.name = 'description';
        meta.content = pageContent.seoDescription || '';
        document.head.appendChild(meta);
      }
      
      // Update meta keywords
      const metaKeywords = document.querySelector('meta[name="keywords"]');
      if (metaKeywords) {
        metaKeywords.setAttribute('content', pageContent.seoKeywords || '');
      } else if (pageContent.seoKeywords) {
        const meta = document.createElement('meta');
        meta.name = 'keywords';
        meta.content = pageContent.seoKeywords;
        document.head.appendChild(meta);
      }
    }
  }, [pageContent]);

  if (isLoading) {
    return (
      <div className="bg-white">
        <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/2 mx-auto mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-200 rounded w-full"></div>
              <div className="h-4 bg-gray-200 rounded w-full"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !pageContent) {
    return (
      <div className="bg-white">
        <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
              Page Not Found
            </h1>
            <p className="mt-4 text-xl text-gray-500">
              The page you're looking for doesn't exist or is temporarily unavailable.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white ${className}`}>
      <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
            {pageContent.title}
          </h1>
        </div>

        <div className="prose prose-lg max-w-none text-gray-600">
          {pageContent.content.split('\n').map((line, index) => {
            const trimmedLine = line.trim();
            if (!trimmedLine) return null;

            // Handle markdown headers
            if (trimmedLine.startsWith('# ')) {
              return (
                <h1 key={index} className="text-3xl font-bold text-gray-900 mt-8 mb-4">
                  {trimmedLine.substring(2)}
                </h1>
              );
            }
            if (trimmedLine.startsWith('## ')) {
              return (
                <h2 key={index} className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                  {trimmedLine.substring(3)}
                </h2>
              );
            }
            if (trimmedLine.startsWith('### ')) {
              return (
                <h3 key={index} className="text-xl font-bold text-gray-900 mt-6 mb-3">
                  {trimmedLine.substring(4)}
                </h3>
              );
            }

            // Handle markdown bold text
            if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**')) {
              return (
                <p key={index} className="font-bold text-gray-900 mb-4">
                  {trimmedLine.substring(2, trimmedLine.length - 2)}
                </p>
              );
            }

            // Handle markdown lists
            if (trimmedLine.startsWith('- ')) {
              return (
                <li key={index} className="mb-2">
                  {trimmedLine.substring(2)}
                </li>
              );
            }

            // Handle markdown tables
            if (trimmedLine.includes('|')) {
              const cells = trimmedLine.split('|').map(cell => cell.trim()).filter(Boolean);
              if (cells.length > 1) {
                return (
                  <div key={index} className="overflow-x-auto mb-4">
                    <table className="min-w-full divide-y divide-gray-200">
                      <tr>
                        {cells.map((cell, cellIndex) => (
                          <td key={cellIndex} className="px-6 py-3 text-left border">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    </table>
                  </div>
                );
              }
            }

            // Regular paragraph
            return (
              <p key={index} className="mb-4">
                {trimmedLine}
              </p>
            );
          })}
        </div>
      </div>
    </div>
  );
}