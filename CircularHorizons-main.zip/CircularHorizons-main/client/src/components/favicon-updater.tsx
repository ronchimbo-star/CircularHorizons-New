import { useEffect } from 'react';
import { useSiteSettings } from '@/hooks/useSiteSettings';

export function FaviconUpdater() {
  const { getSetting } = useSiteSettings();
  const faviconUrl = getSetting('favicon');
  const siteTitle = getSetting('site_title');

  useEffect(() => {
    if (faviconUrl) {
      // Remove existing favicon
      const existingFavicon = document.querySelector('link[rel="shortcut icon"], link[rel="icon"]');
      if (existingFavicon) {
        existingFavicon.remove();
      }

      // Add new favicon
      const link = document.createElement('link');
      link.type = 'image/png';
      link.rel = 'shortcut icon';
      link.href = faviconUrl;
      document.head.appendChild(link);

      // Also add as icon rel
      const iconLink = document.createElement('link');
      iconLink.type = 'image/png';
      iconLink.rel = 'icon';
      iconLink.href = faviconUrl;
      document.head.appendChild(iconLink);
    }
  }, [faviconUrl]);

  useEffect(() => {
    if (siteTitle) {
      document.title = siteTitle;
    }
  }, [siteTitle]);

  return null; // This component doesn't render anything
}