import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSiteSettings } from "@/hooks/useSiteSettings";

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { headerLogo, siteTitle, isLoading } = useSiteSettings();

  const scrollToSection = (sectionId: string) => {
    if (location !== "/") {
      // Navigate to home first, then scroll
      window.location.href = `/#${sectionId}`;
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
    setMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              {headerLogo && !isLoading ? (
                <img 
                  src={headerLogo} 
                  alt={siteTitle || "Circular Horizons"} 
                  className="h-8 w-auto mr-2"
                  onError={(e) => {
                    // Fallback to icon if image fails to load
                    console.log('Header logo failed to load:', headerLogo);
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
              ) : null}
              <Leaf className={`h-8 w-8 text-primary mr-2 ${headerLogo && !isLoading ? 'hidden' : ''}`} />
              <span className="text-xl font-bold text-gray-900">{siteTitle || "Circular Horizons"}</span>
            </Link>
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              <button
                onClick={() => scrollToSection("consultancy")}
                className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium"
              >
                Consultancy
              </button>
              <button
                onClick={() => scrollToSection("green-registry")}
                className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium"
              >
                Green Registry
              </button>
              <button
                onClick={() => scrollToSection("esg-report")}
                className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium"
              >
                ESG Report
              </button>
              <button
                onClick={() => scrollToSection("mizan-esg")}
                className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium"
              >
                Mizan ESG
              </button>

              <Link
                href="/news"
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location === "/news" || location.startsWith("/news/")
                    ? "border-primary text-gray-900"
                    : "border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300"
                }`}
              >
                News
              </Link>
            </div>
          </div>
          <div className="hidden md:ml-6 md:flex md:items-center">
            <Link href="/contact">
              <Button className="bg-primary hover:bg-primary/90 text-white">
                Contact Us
              </Button>
            </Link>
          </div>
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
            <button
              onClick={() => scrollToSection("consultancy")}
              className="block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900 w-full text-left"
            >
              Consultancy
            </button>
            <button
              onClick={() => scrollToSection("green-registry")}
              className="block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900 w-full text-left"
            >
              Green Registry
            </button>
            <button
              onClick={() => scrollToSection("esg-report")}
              className="block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900 w-full text-left"
            >
              ESG Report
            </button>
            <button
              onClick={() => scrollToSection("mizan-esg")}
              className="block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900 w-full text-left"
            >
              Mizan ESG
            </button>

            <Link
              href="/news"
              className="block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900"
              onClick={() => setMobileMenuOpen(false)}
            >
              News
            </Link>
            <Link
              href="/contact"
              className="block px-3 py-2 text-base font-medium text-primary hover:text-primary/80"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact Us
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
