import { Link } from "wouter";
import { Leaf, Linkedin, Twitter, Facebook } from "lucide-react";
import { useSiteSettings } from "@/hooks/useSiteSettings";

export default function Footer() {
  const { footerLogo, siteTitle, isLoading, getSetting } = useSiteSettings();
  
  const scrollToSection = (sectionId: string) => {
    window.location.href = `/#${sectionId}`;
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              {footerLogo && !isLoading ? (
                <img 
                  src={footerLogo} 
                  alt={siteTitle || "Circular Horizons"} 
                  className="h-8 w-auto mr-2"
                  onError={(e) => {
                    // Fallback to icon if image fails to load
                    console.log('Footer logo failed to load:', footerLogo);
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
              ) : null}
              <Leaf className={`h-8 w-8 text-primary mr-2 ${footerLogo && !isLoading ? 'hidden' : ''}`} />
              <span className="text-xl font-bold">{siteTitle || "Circular Horizons"}</span>
            </div>
            <p className="text-gray-400 mb-4">
              Pioneering sustainable solutions for a circular economy future. We help businesses transition to sustainable practices while maintaining profitability.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-6 w-6" />
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <button
                  onClick={() => scrollToSection("consultancy")}
                  className="hover:text-white"
                >
                  Consultancy
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("green-registry")}
                  className="hover:text-white"
                >
                  Green Registry
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("esg-report")}
                  className="hover:text-white"
                >
                  ESG Reporting
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("mizan-esg")}
                  className="hover:text-white"
                >
                  Mizan ESG
                </button>
              </li>

            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/about" className="hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/careers" className="hover:text-white">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-white">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              {getSetting("copyright_text", `© ${new Date().getFullYear()} Circular Horizons. All rights reserved.`)}
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link href="/privacy" className="text-gray-400 hover:text-white text-sm">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-white text-sm">
                Terms of Service
              </Link>
              <Link href="/cookie" className="text-gray-400 hover:text-white text-sm">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
