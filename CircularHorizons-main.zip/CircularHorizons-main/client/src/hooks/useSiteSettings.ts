import { useQuery } from "@tanstack/react-query";

interface SiteSetting {
  id: number;
  key: string;
  value: string | null;
  type: string;
  category: string;
  description: string | null;
  updatedAt: Date;
}

export function useSiteSettings() {
  const { data: settings = [], isLoading, error } = useQuery<SiteSetting[]>({
    queryKey: ["/api/site-settings"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 10 * 60 * 1000, // 10 minutes
  });

  const getSetting = (key: string, defaultValue: string = "") => {
    const setting = settings.find(s => s.key === key);
    return setting?.value || defaultValue;
  };

  const getSettingsByCategory = (category: string) => {
    return settings.filter(s => s.category === category);
  };

  return {
    settings,
    isLoading,
    error,
    getSetting,
    getSettingsByCategory,
    // Helper functions for common settings
    siteTitle: getSetting("site_title", "Circular Horizons"),
    siteTagline: getSetting("site_tagline", "Sustainability Solutions"),
    contactEmail: getSetting("contact_email", "support@circularhorizons.com"),
    whatsappNumber: getSetting("whatsapp_number", "+447398872075"),
    phoneNumber: getSetting("phone_number", "+44 (01322) 879 713"),
    linkedinUrl: getSetting("linkedin_url", ""),
    metaDescription: getSetting("meta_description", "Sustainability solutions and consulting"),
    headerLogo: getSetting("header_logo", ""),
    footerLogo: getSetting("footer_logo", ""),
    favicon: getSetting("favicon", ""),
    primaryColor: getSetting("primary_color", "#2c7d3f"),
  };
}