import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Force cache invalidation - updated after waste institute removal
const version = '2024-07-18-v8-resend-integration';
console.log(`App version: ${version}`);

// Clear any cached data on startup
if ('caches' in window) {
  caches.keys().then(names => {
    names.forEach(name => {
      caches.delete(name);
    });
  });
}

// Force reload if old version detected
const lastVersion = localStorage.getItem('app-version');
if (lastVersion !== version) {
  localStorage.setItem('app-version', version);
  if (lastVersion && lastVersion !== version) {
    console.log('Version changed, forcing reload...');
    window.location.reload();
  }
}

createRoot(document.getElementById("root")!).render(<App />);
