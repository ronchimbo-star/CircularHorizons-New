import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Trash2, Edit, Plus, Upload, Linkedin } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// Helper function to convert Google Drive URLs
const convertGoogleDriveUrl = (url: string): string => {
  if (url.includes('drive.google.com') && url.includes('/file/d/')) {
    const fileId = url.match(/\/file\/d\/([a-zA-Z0-9-_]+)/)?.[1];
    // Use the Google Hosted Libraries URL format which works best for images
    return fileId ? `https://lh3.googleusercontent.com/d/${fileId}` : url;
  }
  return url;
};

// Form schemas
const founderSchema = z.object({
  name: z.string().min(1, "Name is required"),
  title: z.string().min(1, "Title is required"),
  bio: z.string().min(1, "Bio is required"),
  image: z.string().optional(),
  linkedinUrl: z.string().optional(),
});

const teamMemberSchema = z.object({
  name: z.string().min(1, "Name is required"),
  title: z.string().min(1, "Title is required"),
  bio: z.string().optional(),
  image: z.string().optional(),
  linkedinUrl: z.string().optional(),
  order: z.number().min(0).default(0),
});

const valueSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  icon: z.string().optional(),
  iconImage: z.string().optional(),
  iconSize: z.number().min(12).max(200).default(32),
  order: z.number().min(0).default(0),
});

const sectionSchema = z.object({
  sectionKey: z.string().min(1, "Section key is required"),
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  displayOrder: z.number().min(0).default(0),
  isActive: z.boolean().default(true),
});

type FounderFormData = z.infer<typeof founderSchema>;
type TeamMemberFormData = z.infer<typeof teamMemberSchema>;
type ValueFormData = z.infer<typeof valueSchema>;
type SectionFormData = z.infer<typeof sectionSchema>;

export default function AboutManagement() {
  const [editingFounder, setEditingFounder] = useState(false);
  const [editingTeamMember, setEditingTeamMember] = useState<any>(null);
  const [editingValue, setEditingValue] = useState<any>(null);
  const [editingSection, setEditingSection] = useState<any>(null);
  const [showNewTeamMember, setShowNewTeamMember] = useState(false);
  const [showNewValue, setShowNewValue] = useState(false);
  const [showNewSection, setShowNewSection] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Ensure authentication token is available
  React.useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (!token) {
      // Set the auth token for demonstration purposes
      localStorage.setItem('authToken', 'MTphZG1pbjphZG1pbjoxNzUyODQzOTUwNzkw');
    }
  }, []);

  // Query for about page data
  const { data: founder } = useQuery({
    queryKey: ["/api/about/founder"],
    queryFn: async () => {
      const response = await fetch("/api/about/founder");
      if (!response.ok) return null;
      return response.json();
    },
  });

  const { data: team } = useQuery({
    queryKey: ["/api/about/team"],
    queryFn: async () => {
      const response = await fetch("/api/about/team");
      if (!response.ok) return [];
      return response.json();
    },
  });

  const { data: values } = useQuery({
    queryKey: ["/api/about/values"],
    queryFn: async () => {
      const response = await fetch("/api/about/values");
      if (!response.ok) return [];
      return response.json();
    },
  });

  const { data: sections } = useQuery({
    queryKey: ["/api/about/sections"],
    queryFn: async () => {
      const response = await fetch("/api/about/sections");
      if (!response.ok) return [];
      return response.json();
    },
  });

  // Mutations
  const founderMutation = useMutation({
    mutationFn: (data: FounderFormData) => apiRequest("/api/admin/about/founder", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/founder"] });
      setEditingFounder(false);
      toast({ title: "Success", description: "Founder information updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update founder information", variant: "destructive" });
    },
  });

  const teamMemberMutation = useMutation({
    mutationFn: (data: TeamMemberFormData) => apiRequest("/api/admin/about/team", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/team"] });
      setShowNewTeamMember(false);
      toast({ title: "Success", description: "Team member added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add team member", variant: "destructive" });
    },
  });

  const updateTeamMemberMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<TeamMemberFormData> }) => 
      apiRequest(`/api/admin/about/team/${id}`, "PUT", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/team"] });
      setEditingTeamMember(null);
      toast({ title: "Success", description: "Team member updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update team member", variant: "destructive" });
    },
  });

  const deleteTeamMemberMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/about/team/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/team"] });
      toast({ title: "Success", description: "Team member deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete team member", variant: "destructive" });
    },
  });

  const valueMutation = useMutation({
    mutationFn: (data: ValueFormData) => apiRequest("/api/admin/about/values", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/values"] });
      setShowNewValue(false);
      toast({ title: "Success", description: "Value added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add value", variant: "destructive" });
    },
  });

  const updateValueMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<ValueFormData> }) => 
      apiRequest(`/api/admin/about/values/${id}`, "PUT", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/values"] });
      setEditingValue(null);
      toast({ title: "Success", description: "Value updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update value", variant: "destructive" });
    },
  });

  const deleteValueMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/about/values/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/values"] });
      toast({ title: "Success", description: "Value deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete value", variant: "destructive" });
    },
  });

  const sectionMutation = useMutation({
    mutationFn: (data: SectionFormData) => apiRequest("/api/admin/about/sections", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/sections"] });
      setShowNewSection(false);
      toast({ title: "Success", description: "Section added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add section", variant: "destructive" });
    },
  });

  const updateSectionMutation = useMutation({
    mutationFn: ({ sectionKey, data }: { sectionKey: string; data: Partial<SectionFormData> }) => 
      apiRequest(`/api/admin/about/sections/${sectionKey}`, "PUT", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/sections"] });
      setEditingSection(null);
      toast({ title: "Success", description: "Section updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update section", variant: "destructive" });
    },
  });

  const deleteSectionMutation = useMutation({
    mutationFn: (sectionKey: string) => apiRequest(`/api/admin/about/sections/${sectionKey}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about/sections"] });
      toast({ title: "Success", description: "Section deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete section", variant: "destructive" });
    },
  });

  // Form handlers
  const FounderForm = () => {
    const form = useForm<FounderFormData>({
      resolver: zodResolver(founderSchema),
      defaultValues: {
        name: founder?.name || "",
        title: founder?.title || "",
        bio: founder?.bio || "",
        image: founder?.image || "",
        linkedinUrl: founder?.linkedinUrl || "",
      },
    });

    const onSubmit = (data: FounderFormData) => {
      if (data.image) {
        data.image = convertGoogleDriveUrl(data.image);
      }
      founderMutation.mutate(data);
    };

    return (
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input {...form.register("name")} />
          {form.formState.errors.name && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="title">Title</Label>
          <Input {...form.register("title")} />
          {form.formState.errors.title && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.title.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="bio">Bio</Label>
          <Textarea {...form.register("bio")} rows={4} />
          {form.formState.errors.bio && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.bio.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="image">Image URL</Label>
          <Input {...form.register("image")} placeholder="https://example.com/image.jpg or Google Drive link" />
        </div>
        <div>
          <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
          <Input {...form.register("linkedinUrl")} placeholder="https://linkedin.com/in/username" />
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={founderMutation.isPending}>
            {founderMutation.isPending ? "Saving..." : "Save Founder"}
          </Button>
          <Button type="button" variant="outline" onClick={() => setEditingFounder(false)}>
            Cancel
          </Button>
        </div>
      </form>
    );
  };

  const TeamMemberForm = ({ member = null, onClose }: { member?: any; onClose: () => void }) => {
    const form = useForm<TeamMemberFormData>({
      resolver: zodResolver(teamMemberSchema),
      defaultValues: {
        name: member?.name || "",
        title: member?.title || "",
        bio: member?.bio || "",
        image: member?.image || "",
        linkedinUrl: member?.linkedinUrl || "",
        order: member?.order || 0,
      },
    });

    const onSubmit = (data: TeamMemberFormData) => {
      if (data.image) {
        data.image = convertGoogleDriveUrl(data.image);
      }
      if (member) {
        updateTeamMemberMutation.mutate({ id: member.id, data });
      } else {
        teamMemberMutation.mutate(data);
      }
    };

    return (
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input {...form.register("name")} />
          {form.formState.errors.name && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="title">Title</Label>
          <Input {...form.register("title")} />
          {form.formState.errors.title && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.title.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="bio">Bio (optional)</Label>
          <Textarea {...form.register("bio")} rows={3} />
        </div>
        <div>
          <Label htmlFor="image">Image URL</Label>
          <Input {...form.register("image")} placeholder="https://example.com/image.jpg or Google Drive link" />
        </div>
        <div>
          <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
          <Input {...form.register("linkedinUrl")} placeholder="https://linkedin.com/in/username" />
        </div>
        <div>
          <Label htmlFor="order">Display Order</Label>
          <Input {...form.register("order", { valueAsNumber: true })} type="number" min="0" />
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={teamMemberMutation.isPending || updateTeamMemberMutation.isPending}>
            {(teamMemberMutation.isPending || updateTeamMemberMutation.isPending) ? "Saving..." : "Save Team Member"}
          </Button>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </form>
    );
  };

  const ValueForm = ({ value = null, onClose }: { value?: any; onClose: () => void }) => {
    const form = useForm<ValueFormData>({
      resolver: zodResolver(valueSchema),
      defaultValues: {
        title: value?.title || "",
        description: value?.description || "",
        icon: value?.icon || "",
        iconImage: value?.iconImage || "",
        iconSize: value?.iconSize || 32,
        order: value?.order || 0,
      },
    });

    const onSubmit = (data: ValueFormData) => {
      if (data.iconImage) {
        data.iconImage = convertGoogleDriveUrl(data.iconImage);
      }
      if (value) {
        updateValueMutation.mutate({ id: value.id, data });
      } else {
        valueMutation.mutate(data);
      }
    };

    return (
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="title">Title</Label>
          <Input {...form.register("title")} />
          {form.formState.errors.title && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.title.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea {...form.register("description")} rows={3} />
          {form.formState.errors.description && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.description.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="icon">Icon Name (Lucide)</Label>
          <Input {...form.register("icon")} placeholder="e.g., Leaf, Lightbulb, HandHeart" />
        </div>
        <div>
          <Label htmlFor="iconImage">Custom Icon Image URL</Label>
          <Input {...form.register("iconImage")} placeholder="https://example.com/icon.png or Google Drive link" />
        </div>
        <div>
          <Label htmlFor="iconSize">Icon Size (pixels)</Label>
          <Input {...form.register("iconSize", { valueAsNumber: true })} type="number" min="12" max="200" />
        </div>
        <div>
          <Label htmlFor="order">Display Order</Label>
          <Input {...form.register("order", { valueAsNumber: true })} type="number" min="0" />
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={valueMutation.isPending || updateValueMutation.isPending}>
            {(valueMutation.isPending || updateValueMutation.isPending) ? "Saving..." : "Save Value"}
          </Button>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </form>
    );
  };

  const SectionForm = ({ section = null, onClose }: { section?: any; onClose: () => void }) => {
    const form = useForm<SectionFormData>({
      resolver: zodResolver(sectionSchema),
      defaultValues: {
        sectionKey: section?.sectionKey || "",
        title: section?.title || "",
        content: section?.content || "",
        displayOrder: section?.displayOrder || 0,
        isActive: section?.isActive ?? true,
      },
    });

    const onSubmit = (data: SectionFormData) => {
      if (section) {
        updateSectionMutation.mutate({ sectionKey: section.sectionKey, data });
      } else {
        sectionMutation.mutate(data);
      }
    };

    return (
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="sectionKey">Section Key</Label>
          <Input 
            {...form.register("sectionKey")} 
            placeholder="e.g., mission, vision, values" 
            disabled={!!section}
          />
          {form.formState.errors.sectionKey && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.sectionKey.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="title">Title</Label>
          <Input {...form.register("title")} />
          {form.formState.errors.title && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.title.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="content">Content</Label>
          <Textarea {...form.register("content")} rows={4} />
          {form.formState.errors.content && (
            <p className="text-red-500 text-sm mt-1">{form.formState.errors.content.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="displayOrder">Display Order</Label>
          <Input {...form.register("displayOrder", { valueAsNumber: true })} type="number" min="0" />
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={sectionMutation.isPending || updateSectionMutation.isPending}>
            {(sectionMutation.isPending || updateSectionMutation.isPending) ? "Saving..." : "Save Section"}
          </Button>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </form>
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">About Page Management</h1>
      </div>

      {/* Founder Section */}
      <Card>
        <CardHeader>
          <CardTitle>Founder Information</CardTitle>
          <CardDescription>Manage the founder's details and bio</CardDescription>
        </CardHeader>
        <CardContent>
          {editingFounder ? (
            <FounderForm />
          ) : (
            <div>
              {founder ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    {founder.image && (
                      <img src={founder.image} alt={founder.name} className="w-16 h-16 rounded-full object-cover" />
                    )}
                    <div>
                      <h3 className="text-lg font-semibold">{founder.name}</h3>
                      <p className="text-gray-600">{founder.title}</p>
                      {founder.linkedinUrl && (
                        <a href={founder.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                          <Linkedin className="w-4 h-4 inline mr-1" />
                          LinkedIn
                        </a>
                      )}
                    </div>
                  </div>
                  <p className="text-gray-700">{founder.bio}</p>
                </div>
              ) : (
                <p className="text-gray-500">No founder information available</p>
              )}
              <Button onClick={() => setEditingFounder(true)} className="mt-4">
                <Edit className="w-4 h-4 mr-2" />
                {founder ? "Edit" : "Add"} Founder
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Team Section */}
      <Card>
        <CardHeader>
          <CardTitle>Team Members</CardTitle>
          <CardDescription>Manage team member profiles</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {team?.map((member: any) => (
              <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  {member.image && (
                    <img src={member.image} alt={member.name} className="w-12 h-12 rounded-full object-cover" />
                  )}
                  <div>
                    <h3 className="font-semibold">{member.name}</h3>
                    <p className="text-gray-600">{member.title}</p>
                    {member.linkedinUrl && (
                      <a href={member.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm">
                        <Linkedin className="w-3 h-3 inline mr-1" />
                        LinkedIn
                      </a>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => setEditingTeamMember(member)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => deleteTeamMemberMutation.mutate(member.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            
            <Button onClick={() => setShowNewTeamMember(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Team Member
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Values Section */}
      <Card>
        <CardHeader>
          <CardTitle>Company Values</CardTitle>
          <CardDescription>Manage the company values and their icons</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {values?.map((value: any) => (
              <div key={value.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  {value.iconImage ? (
                    <img src={value.iconImage} alt={value.title} className="w-12 h-12 object-contain" />
                  ) : value.icon ? (
                    <div className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center">
                      <span className="text-xs">{value.icon}</span>
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gray-200"></div>
                  )}
                  <div>
                    <h3 className="font-semibold">{value.title}</h3>
                    <p className="text-gray-600 text-sm">{value.description}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => setEditingValue(value)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => deleteValueMutation.mutate(value.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            
            <Button onClick={() => setShowNewValue(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Value
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* About Sections */}
      <Card>
        <CardHeader>
          <CardTitle>About Sections</CardTitle>
          <CardDescription>Manage Mission, Vision, and other content sections</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sections?.map((section: any) => (
              <div key={section.sectionKey} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-semibold">{section.title}</h3>
                  <p className="text-gray-600 text-sm">{section.content.substring(0, 100)}...</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline">Key: {section.sectionKey}</Badge>
                    <Badge variant="outline">Order: {section.displayOrder}</Badge>
                    <Badge variant={section.isActive ? "default" : "secondary"}>
                      {section.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => setEditingSection(section)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => deleteSectionMutation.mutate(section.sectionKey)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            
            <Button onClick={() => setShowNewSection(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Section
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      <Dialog open={showNewTeamMember} onOpenChange={setShowNewTeamMember}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
          </DialogHeader>
          <TeamMemberForm onClose={() => setShowNewTeamMember(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingTeamMember} onOpenChange={(open) => !open && setEditingTeamMember(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Team Member</DialogTitle>
          </DialogHeader>
          {editingTeamMember && <TeamMemberForm member={editingTeamMember} onClose={() => setEditingTeamMember(null)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={showNewValue} onOpenChange={setShowNewValue}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Company Value</DialogTitle>
          </DialogHeader>
          <ValueForm onClose={() => setShowNewValue(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingValue} onOpenChange={(open) => !open && setEditingValue(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Company Value</DialogTitle>
          </DialogHeader>
          {editingValue && <ValueForm value={editingValue} onClose={() => setEditingValue(null)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={showNewSection} onOpenChange={setShowNewSection}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Section</DialogTitle>
          </DialogHeader>
          <SectionForm onClose={() => setShowNewSection(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingSection} onOpenChange={() => setEditingSection(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Section</DialogTitle>
          </DialogHeader>
          <SectionForm section={editingSection} onClose={() => setEditingSection(null)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}