import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, Plus, Eye, EyeOff, ArrowUp, ArrowDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import type { HomepageSection, SectionCard } from "@shared/schema";

// Helper function to convert Google Drive URLs to direct image URLs
function convertGoogleDriveUrl(url: string): string {
  if (url.includes('drive.google.com/file/d/')) {
    const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      return `https://lh3.googleusercontent.com/d/${match[1]}`;
    }
  }
  return url;
}

const sectionSchema = z.object({
  sectionName: z.string().min(1, "Section name is required"),
  title: z.string().min(1, "Title is required"),
  subtitle: z.string().optional(),
  description: z.string().optional(),
  backgroundImage: z.string().optional(),
  backgroundColor: z.string().optional(),
  textColor: z.string().optional(),
  overlayText: z.string().optional(),
  buttonText: z.string().optional(),
  buttonLink: z.string().optional(),
  icon: z.string().optional(),
  iconImage: z.string().optional(),
  iconSize: z.number().min(12).max(200).optional(),
  isVisible: z.boolean(),
  sortOrder: z.number(),
});

const cardSchema = z.object({
  sectionId: z.number(),
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  icon: z.string().optional(),
  iconImage: z.string().optional(),
  iconSize: z.number().min(12).max(200).optional(),
  image: z.string().optional(),
  link: z.string().optional(),
  buttonText: z.string().optional(),
  sortOrder: z.number(),
  isVisible: z.boolean(),
});

type SectionForm = z.infer<typeof sectionSchema>;
type CardForm = z.infer<typeof cardSchema>;

// Popular Lucide icons for selection
const iconOptions = [
  "Recycle", "Leaf", "Globe", "TrendingUp", "BarChart3", "Users", 
  "Building", "Award", "Shield", "Target", "Zap", "Lightbulb",
  "CheckCircle", "Star", "Heart", "Rocket", "Calendar", "Clock"
];

export default function HomepageSections() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [editingSection, setEditingSection] = useState<HomepageSection | null>(null);
  const [editingCard, setEditingCard] = useState<SectionCard | null>(null);
  const [selectedSection, setSelectedSection] = useState<HomepageSection | null>(null);
  const [isAddingSection, setIsAddingSection] = useState(false);
  const [isAddingCard, setIsAddingCard] = useState(false);

  const { data: sections = [], isLoading: sectionsLoading } = useQuery({
    queryKey: ["/api/homepage-sections"],
  });

  const { data: cards = [] } = useQuery({
    queryKey: ["/api/section-cards", selectedSection?.id],
    enabled: !!selectedSection?.id,
  });

  const sectionMutation = useMutation({
    mutationFn: async (data: SectionForm) => {
      // Convert Google Drive URLs for icon images
      if (data.iconImage) {
        data.iconImage = convertGoogleDriveUrl(data.iconImage);
      }
      
      if (editingSection) {
        return apiRequest(`/api/admin/homepage-sections/${editingSection.id}`, "PUT", data);
      } else {
        return apiRequest("/api/admin/homepage-sections", "POST", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/homepage-sections"] });
      setEditingSection(null);
      setIsAddingSection(false);
      toast({
        title: "Success",
        description: "Section saved successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cardMutation = useMutation({
    mutationFn: async (data: CardForm) => {
      // Convert Google Drive URLs for icon images
      if (data.iconImage) {
        data.iconImage = convertGoogleDriveUrl(data.iconImage);
      }
      
      if (editingCard) {
        return apiRequest(`/api/admin/section-cards/${editingCard.id}`, "PUT", data);
      } else {
        return apiRequest("/api/admin/section-cards", "POST", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/section-cards", selectedSection?.id] });
      setEditingCard(null);
      setIsAddingCard(false);
      toast({
        title: "Success",
        description: "Card saved successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteSectionMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/admin/homepage-sections/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/homepage-sections"] });
      toast({
        title: "Success",
        description: "Section deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteCardMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/admin/section-cards/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/section-cards", selectedSection?.id] });
      toast({
        title: "Success",
        description: "Card deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sectionForm = useForm<SectionForm>({
    resolver: zodResolver(sectionSchema),
    defaultValues: {
      sectionName: "",
      title: "",
      subtitle: "",
      description: "",
      backgroundImage: "",
      backgroundColor: "#f9fafb",
      textColor: "#111827",
      overlayText: "",
      buttonText: "",
      buttonLink: "",
      icon: "",
      iconImage: "",
      iconSize: 24,
      isVisible: true,
      sortOrder: 0,
    },
  });

  const cardForm = useForm<CardForm>({
    resolver: zodResolver(cardSchema),
    defaultValues: {
      sectionId: 0,
      title: "",
      description: "",
      icon: "",
      iconImage: "",
      iconSize: 24,
      image: "",
      link: "",
      buttonText: "",
      sortOrder: 0,
      isVisible: true,
    },
  });

  const handleEditSection = (section: HomepageSection) => {
    setEditingSection(section);
    sectionForm.reset(section);
    setIsAddingSection(true);
  };

  const handleAddSection = () => {
    setEditingSection(null);
    sectionForm.reset({
      sectionName: "",
      title: "",
      subtitle: "",
      description: "",
      backgroundImage: "",
      backgroundColor: "#f9fafb",
      textColor: "#111827",
      overlayText: "",
      buttonText: "",
      buttonLink: "",
      icon: "",
      iconImage: "",
      iconSize: 24,
      isVisible: true,
      sortOrder: sections.length,
    });
    setIsAddingSection(true);
  };

  const handleEditCard = (card: SectionCard) => {
    setEditingCard(card);
    cardForm.reset(card);
    setIsAddingCard(true);
  };

  const handleAddCard = () => {
    if (!selectedSection) return;
    setEditingCard(null);
    cardForm.reset({
      sectionId: selectedSection.id,
      title: "",
      description: "",
      icon: "",
      iconImage: "",
      iconSize: 24,
      image: "",
      link: "",
      buttonText: "",
      sortOrder: cards.length,
      isVisible: true,
    });
    setIsAddingCard(true);
  };

  if (sectionsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Homepage Sections</h1>
        <Button onClick={handleAddSection}>
          <Plus className="h-4 w-4 mr-2" />
          Add Section
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sections List */}
        <Card>
          <CardHeader>
            <CardTitle>Sections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sections.map((section: HomepageSection) => (
                <div
                  key={section.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedSection?.id === section.id
                      ? "border-primary bg-primary/5"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedSection(section)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      {section.isVisible ? (
                        <Eye className="h-4 w-4 text-green-600 flex-shrink-0" />
                      ) : (
                        <EyeOff className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      )}
                      <div className="min-w-0 flex-1">
                        <h3 className="font-medium text-sm truncate">{section.title}</h3>
                        <p className="text-xs text-gray-500 truncate">{section.sectionName}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 flex-shrink-0 ml-2">
                      <Badge variant="secondary" className="text-xs">{section.sortOrder}</Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditSection(section);
                        }}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm("Are you sure you want to delete this section?")) {
                            deleteSectionMutation.mutate(section.id);
                          }
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Cards List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-sm">Cards {selectedSection ? `- ${selectedSection.title}` : ""}</span>
              {selectedSection && (
                <Button size="sm" onClick={handleAddCard}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Card
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedSection ? (
              <div className="space-y-3">
                {cards.map((card: SectionCard) => (
                  <div
                    key={card.id}
                    className="p-4 border rounded-lg border-gray-200 hover:border-gray-300"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        {card.isVisible ? (
                          <Eye className="h-4 w-4 text-green-600 flex-shrink-0" />
                        ) : (
                          <EyeOff className="h-4 w-4 text-gray-400 flex-shrink-0" />
                        )}
                        <div className="min-w-0 flex-1">
                          <h4 className="font-medium text-sm truncate">{card.title}</h4>
                          {card.description && (
                            <p className="text-xs text-gray-500 truncate max-w-xs">
                              {card.description}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-1 flex-shrink-0 ml-2">
                        <Badge variant="secondary" className="text-xs">{card.sortOrder}</Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => handleEditCard(card)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this card?")) {
                              deleteCardMutation.mutate(card.id);
                            }
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {cards.length === 0 && (
                  <p className="text-gray-500 text-center py-8 text-sm">
                    No cards found for this section
                  </p>
                )}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8 text-sm">
                Select a section to view its cards
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Section Dialog */}
      <Dialog open={isAddingSection} onOpenChange={setIsAddingSection}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSection ? "Edit Section" : "Add New Section"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={sectionForm.handleSubmit((data) => sectionMutation.mutate(data))}
            className="space-y-4"
          >
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="sectionName">Section Name</Label>
                <Input
                  id="sectionName"
                  placeholder="e.g., hero, consultancy"
                  {...sectionForm.register("sectionName")}
                />
                {sectionForm.formState.errors.sectionName && (
                  <p className="text-red-500 text-sm mt-1">
                    {sectionForm.formState.errors.sectionName.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Section title"
                  {...sectionForm.register("title")}
                />
                {sectionForm.formState.errors.title && (
                  <p className="text-red-500 text-sm mt-1">
                    {sectionForm.formState.errors.title.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="subtitle">Subtitle</Label>
              <Input
                id="subtitle"
                placeholder="Optional subtitle"
                {...sectionForm.register("subtitle")}
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Section description"
                {...sectionForm.register("description")}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="icon">Icon</Label>
                <Select
                  value={sectionForm.watch("icon")}
                  onValueChange={(value) => sectionForm.setValue("icon", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select an icon" />
                  </SelectTrigger>
                  <SelectContent>
                    {iconOptions.map((icon) => (
                      <SelectItem key={icon} value={icon}>
                        {icon}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="iconImage">Icon Image URL</Label>
                <Input
                  id="iconImage"
                  placeholder="https://example.com/icon.png or Google Drive URL"
                  {...sectionForm.register("iconImage")}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Use either icon above or custom image URL. Google Drive links will be converted automatically.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="iconSize">Icon Size (px)</Label>
                <Input
                  id="iconSize"
                  type="number"
                  min="12"
                  max="200"
                  placeholder="24"
                  {...sectionForm.register("iconSize", { valueAsNumber: true })}
                />
              </div>
              <div>
                <Label htmlFor="sortOrder">Sort Order</Label>
                <Input
                  id="sortOrder"
                  type="number"
                  {...sectionForm.register("sortOrder", { valueAsNumber: true })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="backgroundImage">Background Image URL</Label>
              <Input
                id="backgroundImage"
                placeholder="https://example.com/image.jpg"
                {...sectionForm.register("backgroundImage")}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="backgroundColor">Background Color</Label>
                <Input
                  id="backgroundColor"
                  type="color"
                  {...sectionForm.register("backgroundColor")}
                />
              </div>
              <div>
                <Label htmlFor="textColor">Text Color</Label>
                <Input
                  id="textColor"
                  type="color"
                  {...sectionForm.register("textColor")}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="overlayText">Overlay Text</Label>
              <Input
                id="overlayText"
                placeholder="Text to overlay on background image"
                {...sectionForm.register("overlayText")}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="buttonText">Button Text</Label>
                <Input
                  id="buttonText"
                  placeholder="e.g., Learn More"
                  {...sectionForm.register("buttonText")}
                />
              </div>
              <div>
                <Label htmlFor="buttonLink">Button Link</Label>
                <Input
                  id="buttonLink"
                  placeholder="e.g., /contact"
                  {...sectionForm.register("buttonLink")}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="isVisible"
                checked={sectionForm.watch("isVisible")}
                onCheckedChange={(checked) => sectionForm.setValue("isVisible", checked)}
              />
              <Label htmlFor="isVisible">Visible</Label>
            </div>

            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsAddingSection(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={sectionMutation.isPending}>
                {sectionMutation.isPending ? "Saving..." : "Save Section"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Card Dialog */}
      <Dialog open={isAddingCard} onOpenChange={setIsAddingCard}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingCard ? "Edit Card" : "Add New Card"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={cardForm.handleSubmit((data) => cardMutation.mutate(data))}
            className="space-y-4"
          >
            <div>
              <Label htmlFor="cardTitle">Title</Label>
              <Input
                id="cardTitle"
                placeholder="Card title"
                {...cardForm.register("title")}
              />
              {cardForm.formState.errors.title && (
                <p className="text-red-500 text-sm mt-1">
                  {cardForm.formState.errors.title.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="cardDescription">Description</Label>
              <Textarea
                id="cardDescription"
                placeholder="Card description"
                {...cardForm.register("description")}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cardIcon">Icon</Label>
                <Select
                  value={cardForm.watch("icon")}
                  onValueChange={(value) => cardForm.setValue("icon", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select an icon" />
                  </SelectTrigger>
                  <SelectContent>
                    {iconOptions.map((icon) => (
                      <SelectItem key={icon} value={icon}>
                        {icon}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="cardIconImage">Icon Image URL</Label>
                <Input
                  id="cardIconImage"
                  placeholder="https://example.com/icon.png or Google Drive URL"
                  {...cardForm.register("iconImage")}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Use either icon above or custom image URL. Google Drive links will be converted automatically.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cardIconSize">Icon Size (px)</Label>
                <Input
                  id="cardIconSize"
                  type="number"
                  min="12"
                  max="200"
                  placeholder="24"
                  {...cardForm.register("iconSize", { valueAsNumber: true })}
                />
              </div>
              <div>
                <Label htmlFor="cardSortOrder">Sort Order</Label>
                <Input
                  id="cardSortOrder"
                  type="number"
                  {...cardForm.register("sortOrder", { valueAsNumber: true })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="cardImage">Image URL</Label>
              <Input
                id="cardImage"
                placeholder="https://example.com/image.jpg"
                {...cardForm.register("image")}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cardButtonText">Button Text</Label>
                <Input
                  id="cardButtonText"
                  placeholder="e.g., Learn More"
                  {...cardForm.register("buttonText")}
                />
              </div>
              <div>
                <Label htmlFor="cardLink">Link</Label>
                <Input
                  id="cardLink"
                  placeholder="e.g., /contact"
                  {...cardForm.register("link")}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="cardIsVisible"
                checked={cardForm.watch("isVisible")}
                onCheckedChange={(checked) => cardForm.setValue("isVisible", checked)}
              />
              <Label htmlFor="cardIsVisible">Visible</Label>
            </div>

            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsAddingCard(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={cardMutation.isPending}>
                {cardMutation.isPending ? "Saving..." : "Save Card"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}