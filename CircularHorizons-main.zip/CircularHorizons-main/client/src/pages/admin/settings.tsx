import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings, 
  Globe, 
  Eye, 
  Share2, 
  Image, 
  FileText,
  BarChart3,
  Palette 
} from "lucide-react";

const settingSchema = z.object({
  key: z.string().min(1, "Key is required"),
  value: z.string().optional(),
  type: z.string().default("text"),
  category: z.string().default("general"),
  description: z.string().optional(),
});

type SettingFormData = z.infer<typeof settingSchema>;

interface SiteSetting {
  id: number;
  key: string;
  value: string | null;
  type: string;
  category: string;
  description: string | null;
  updatedAt: Date;
}

// Helper function to convert Google Drive URLs to direct image URLs
function convertGoogleDriveUrl(url: string): string {
  if (url.includes('drive.google.com/file/d/')) {
    const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      return `https://lh3.googleusercontent.com/d/${match[1]}`;
    }
  }
  return url;
}

// Default settings configuration
const defaultSettings = {
  branding: [
    { key: "site_title", label: "Site Title", type: "text", description: "Main site title displayed in browser tabs" },
    { key: "site_tagline", label: "Site Tagline", type: "text", description: "Short description of your site" },
    { key: "header_logo", label: "Header Logo URL", type: "text", description: "URL to your header logo image. Google Drive links will be automatically converted." },
    { key: "footer_logo", label: "Footer Logo URL", type: "text", description: "URL to your footer logo image. Google Drive links will be automatically converted." },
    { key: "favicon", label: "Favicon URL", type: "text", description: "URL to your site favicon. Google Drive links will be automatically converted." },
    { key: "primary_color", label: "Primary Color", type: "color", description: "Main brand color (hex code)" },
    { key: "copyright_text", label: "Copyright Text", type: "text", description: "Footer copyright text" },
  ],
  seo: [
    { key: "meta_description", label: "Meta Description", type: "textarea", description: "Default meta description for pages" },
    { key: "meta_keywords", label: "Meta Keywords", type: "textarea", description: "Default meta keywords (comma-separated)" },
    { key: "google_analytics", label: "Google Analytics ID", type: "text", description: "Google Analytics tracking ID (e.g., G-XXXXXXXXXX)" },
    { key: "google_tag_manager", label: "Google Tag Manager ID", type: "text", description: "Google Tag Manager container ID" },
    { key: "facebook_pixel", label: "Facebook Pixel ID", type: "text", description: "Facebook Pixel tracking ID" },
  ],
  social: [
    { key: "linkedin_url", label: "LinkedIn URL", type: "text", description: "Company LinkedIn profile URL" },
    { key: "twitter_url", label: "Twitter URL", type: "text", description: "Company Twitter profile URL" },
    { key: "facebook_url", label: "Facebook URL", type: "text", description: "Company Facebook page URL" },
    { key: "instagram_url", label: "Instagram URL", type: "text", description: "Company Instagram profile URL" },
    { key: "youtube_url", label: "YouTube URL", type: "text", description: "Company YouTube channel URL" },
  ],
  contact: [
    { key: "contact_email", label: "Contact Email", type: "email", description: "Main contact email address" },
    { key: "support_email", label: "Support Email", type: "email", description: "Support email address" },
    { key: "phone_number", label: "Phone Number", type: "tel", description: "Main phone number" },
    { key: "whatsapp_number", label: "WhatsApp Number", type: "tel", description: "WhatsApp contact number" },
    { key: "address", label: "Address", type: "textarea", description: "Physical address" },
  ],
};

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState("branding");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings = [], isLoading } = useQuery({
    queryKey: ["/api/site-settings"],
  });

  const updateSettingMutation = useMutation({
    mutationFn: async (data: SettingFormData) => {
      // Convert Google Drive URLs for logo settings
      if (data.key.includes('logo') || data.key.includes('favicon')) {
        data.value = convertGoogleDriveUrl(data.value || '');
      }
      return apiRequest("/api/admin/site-settings", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Setting updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/site-settings"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update setting",
        variant: "destructive",
      });
    },
  });

  const form = useForm<SettingFormData>({
    resolver: zodResolver(settingSchema),
  });

  const getCurrentValue = (key: string) => {
    const setting = settings.find((s: SiteSetting) => s.key === key);
    return setting?.value || "";
  };

  const handleSettingUpdate = (key: string, value: string, type: string, category: string, description?: string) => {
    updateSettingMutation.mutate({
      key,
      value,
      type,
      category,
      description,
    });
  };

  // State for all setting values
  const [settingValues, setSettingValues] = useState<Record<string, string>>({});

  // Initialize setting values when settings load
  useEffect(() => {
    if (settings) {
      const initialValues: Record<string, string> = {};
      settings.forEach((setting: SiteSetting) => {
        initialValues[setting.key] = setting.value || "";
      });
      setSettingValues(initialValues);
    }
  }, [settings]);

  const handleSettingChange = (key: string, value: string) => {
    setSettingValues(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const renderSettingInput = (setting: any, category: string) => {
    const currentValue = settingValues[setting.key] || "";

    const handleSave = () => {
      handleSettingUpdate(setting.key, currentValue, setting.type, category, setting.description);
    };

    return (
      <Card key={setting.key} className="mb-4">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-sm font-medium">{setting.label}</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">{setting.description}</p>
            </div>
            <Button
              size="sm"
              onClick={handleSave}
              disabled={updateSettingMutation.isPending}
            >
              Save
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {setting.type === "textarea" ? (
            <Textarea
              value={currentValue}
              onChange={(e) => handleSettingChange(setting.key, e.target.value)}
              placeholder={`Enter ${setting.label.toLowerCase()}...`}
              className="min-h-[80px]"
            />
          ) : setting.type === "color" ? (
            <div className="flex gap-2">
              <Input
                type="color"
                value={currentValue || "#2c7d3f"}
                onChange={(e) => handleSettingChange(setting.key, e.target.value)}
                className="w-16 h-10"
              />
              <Input
                type="text"
                value={currentValue}
                onChange={(e) => handleSettingChange(setting.key, e.target.value)}
                placeholder="#2c7d3f"
              />
            </div>
          ) : (
            <Input
              type={setting.type}
              value={currentValue}
              onChange={(e) => handleSettingChange(setting.key, e.target.value)}
              placeholder={`Enter ${setting.label.toLowerCase()}...`}
            />
          )}
        </CardContent>
      </Card>
    );
  };

  const getTabIcon = (tab: string) => {
    switch (tab) {
      case "branding":
        return <Palette className="h-4 w-4" />;
      case "seo":
        return <BarChart3 className="h-4 w-4" />;
      case "social":
        return <Share2 className="h-4 w-4" />;
      case "contact":
        return <Globe className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Site Settings</h1>
        <p className="text-muted-foreground">
          Configure your site's branding, SEO, social links, and contact information.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="branding" className="flex items-center gap-2">
            {getTabIcon("branding")}
            Branding
          </TabsTrigger>
          <TabsTrigger value="seo" className="flex items-center gap-2">
            {getTabIcon("seo")}
            SEO
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center gap-2">
            {getTabIcon("social")}
            Social
          </TabsTrigger>
          <TabsTrigger value="contact" className="flex items-center gap-2">
            {getTabIcon("contact")}
            Contact
          </TabsTrigger>
        </TabsList>

        <TabsContent value="branding" className="mt-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Branding & Visual Identity</h3>
            {defaultSettings.branding.map((setting) => renderSettingInput(setting, "branding"))}
          </div>
        </TabsContent>

        <TabsContent value="seo" className="mt-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">SEO & Analytics</h3>
            {defaultSettings.seo.map((setting) => renderSettingInput(setting, "seo"))}
          </div>
        </TabsContent>

        <TabsContent value="social" className="mt-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Social Media Links</h3>
            {defaultSettings.social.map((setting) => renderSettingInput(setting, "social"))}
          </div>
        </TabsContent>

        <TabsContent value="contact" className="mt-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
            {defaultSettings.contact.map((setting) => renderSettingInput(setting, "contact"))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}