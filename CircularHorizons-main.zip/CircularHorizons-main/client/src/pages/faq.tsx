import DynamicPage from "@/components/dynamic-page";

export default function FAQ() {
  return <DynamicPage pageName="faq" />;
}