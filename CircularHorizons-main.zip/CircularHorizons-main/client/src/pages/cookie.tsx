import DynamicPage from "@/components/dynamic-page";

export default function Cookie() {
  return <DynamicPage pageName="cookie" />;
}