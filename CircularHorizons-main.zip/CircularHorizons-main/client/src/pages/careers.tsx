import DynamicPage from "@/components/dynamic-page";

export default function Careers() {
  return <DynamicPage pageName="careers" />;
}