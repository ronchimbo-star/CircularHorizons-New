import { Linkedin, Leaf, Lightbulb, HandHeart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import * as Icons from "lucide-react";

export default function About() {
  const { data: pageContent } = useQuery({
    queryKey: ["/api/page-content", "about"],
    queryFn: async () => {
      const response = await fetch("/api/page-content/about");
      if (!response.ok) return null;
      return response.json();
    },
  });

  const { data: founder } = useQuery({
    queryKey: ["/api/about/founder"],
    queryFn: async () => {
      const response = await fetch("/api/about/founder");
      if (!response.ok) return null;
      return response.json();
    },
  });

  const { data: team } = useQuery({
    queryKey: ["/api/about/team"],
    queryFn: async () => {
      const response = await fetch("/api/about/team");
      if (!response.ok) return [];
      return response.json();
    },
  });

  const { data: values } = useQuery({
    queryKey: ["/api/about/values"],
    queryFn: async () => {
      const response = await fetch("/api/about/values");
      if (!response.ok) return [];
      return response.json();
    },
  });

  const { data: sections } = useQuery({
    queryKey: ["/api/about/sections"],
    queryFn: async () => {
      const response = await fetch("/api/about/sections");
      if (!response.ok) return [];
      return response.json();
    },
  });

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
            {pageContent?.title || "About Circular Horizons"}
          </h1>
          {pageContent?.content && (
            <div className="mt-8 prose prose-lg max-w-4xl mx-auto text-gray-600">
              {pageContent.content.split('\n').map((paragraph, index) => (
                paragraph.trim() && (
                  <p key={index} className="mb-4">
                    {paragraph.trim()}
                  </p>
                )
              ))}
            </div>
          )}
        </div>

        {/* Mission & Vision */}
        {sections && sections.length > 0 && (
          <div className="mt-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {sections.map((section, index) => (
                <div 
                  key={section.sectionKey}
                  className={`p-8 rounded-lg ${
                    index % 2 === 0 
                      ? 'bg-primary text-white' 
                      : 'bg-gray-50 text-gray-900'
                  }`}
                >
                  <h2 className="text-2xl font-bold mb-4">{section.title}</h2>
                  <p className={`text-lg ${
                    index % 2 === 0 ? 'text-white' : 'text-gray-600'
                  }`}>
                    {section.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Team Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900">Meet the Team</h2>
            <p className="mt-4 text-lg text-gray-500">
              A diverse group of sustainability experts, consultants, and technology professionals
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Founder as first team member */}
            <div className="text-center">
              <img
                className="mx-auto h-32 w-32 rounded-full object-cover"
                src={founder?.image || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"}
                alt={founder?.name || "Ron Chimbo"}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  if (target.src !== "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80") {
                    target.src = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80";
                  }
                }}
              />
              <h3 className="mt-4 text-lg font-bold text-gray-900">{founder?.name || "Ron Chimbo"}</h3>
              <p className="text-primary">{founder?.title || "Founder & CEO"}</p>
              {founder?.bio && (
                <p className="mt-2 text-sm text-gray-600">{founder.bio}</p>
              )}
              {!founder?.bio && (
                <p className="mt-2 text-sm text-gray-600">
                  Visionary leader in sustainable business practices with over 15 years of experience in environmental consulting.
                </p>
              )}
              {founder?.linkedinUrl && (
                <div className="mt-2">
                  <a
                    href={founder.linkedinUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:text-primary/80"
                  >
                    <Linkedin className="h-6 w-6 mx-auto" />
                  </a>
                </div>
              )}
            </div>

            {/* Other team members */}
            {team && team.length > 0 ? (
              team.map((member) => (
                <div key={member.id} className="text-center">
                  <img
                    className="mx-auto h-32 w-32 rounded-full object-cover"
                    src={member.image || "https://images.unsplash.com/photo-1494790108755-2616b612b1e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"}
                    alt={member.name}
                  />
                  <h3 className="mt-4 text-lg font-bold text-gray-900">{member.name}</h3>
                  <p className="text-primary">{member.title}</p>
                  {member.bio && (
                    <p className="mt-2 text-sm text-gray-600">{member.bio}</p>
                  )}
                  {member.linkedinUrl && (
                    <div className="mt-2">
                      <a
                        href={member.linkedinUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:text-primary/80"
                      >
                        <Linkedin className="h-6 w-6 mx-auto" />
                      </a>
                    </div>
                  )}
                </div>
              ))
            ) : (
              // Default team members if none in database
              <>
                <div className="text-center">
                  <img
                    className="mx-auto h-32 w-32 rounded-full object-cover"
                    src="https://images.unsplash.com/photo-1494790108755-2616b612b1e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                    alt="Team Member"
                  />
                  <h3 className="mt-4 text-lg font-bold text-gray-900">Derek Musoni</h3>
                  <p className="text-primary">ESG Specialist</p>
                </div>
                <div className="text-center">
                  <img
                    className="mx-auto h-32 w-32 rounded-full object-cover"
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                    alt="Team Member"
                  />
                  <h3 className="mt-4 text-lg font-bold text-gray-900">Michael Chen</h3>
                  <p className="text-primary">Circular Economy Consultant</p>
                </div>
                <div className="text-center">
                  <img
                    className="mx-auto h-32 w-32 rounded-full object-cover"
                    src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                    alt="Team Member"
                  />
                  <h3 className="mt-4 text-lg font-bold text-gray-900">Emily Rodriguez</h3>
                  <p className="text-primary">Technology Director</p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Values Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900">Our Values</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values && values.length > 0 ? (
              values.map((value) => {
                const IconComponent = value.icon ? (Icons as any)[value.icon] : null;
                const iconSize = value.iconSize || 32;
                
                return (
                  <div key={value.id} className="text-center">
                    <div className="mx-auto flex items-center justify-center mb-4">
                      {value.iconImage ? (
                        <img
                          src={value.iconImage}
                          alt={`${value.title} icon`}
                          className="object-contain"
                          style={{ width: iconSize + 'px', height: iconSize + 'px' }}
                        />
                      ) : IconComponent ? (
                        <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                          <IconComponent style={{ width: iconSize + 'px', height: iconSize + 'px' }} />
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                          <Leaf className="h-8 w-8" />
                        </div>
                      )}
                    </div>
                    <h3 className="mt-4 text-xl font-bold text-gray-900">{value.title}</h3>
                    <p className="mt-2 text-gray-600">{value.description}</p>
                  </div>
                );
              })
            ) : (
              // Default values if none in database
              <>
                <div className="text-center">
                  <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                    <Leaf className="h-8 w-8" />
                  </div>
                  <h3 className="mt-4 text-xl font-bold text-gray-900">Sustainability</h3>
                  <p className="mt-2 text-gray-600">We practice what we preach, embedding sustainability into every aspect of our operations.</p>
                </div>
                <div className="text-center">
                  <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                    <Lightbulb className="h-8 w-8" />
                  </div>
                  <h3 className="mt-4 text-xl font-bold text-gray-900">Innovation</h3>
                  <p className="mt-2 text-gray-600">We continuously develop cutting-edge solutions to address emerging sustainability challenges.</p>
                </div>
                <div className="text-center">
                  <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-primary text-white">
                    <HandHeart className="h-8 w-8" />
                  </div>
                  <h3 className="mt-4 text-xl font-bold text-gray-900">Collaboration</h3>
                  <p className="mt-2 text-gray-600">We believe in the power of partnerships to create meaningful change across industries.</p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Call to Action Banner */}
        <div className="mt-20 bg-primary text-white py-16 px-8 rounded-lg">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold mb-4">
              Ready to accelerate your sustainability journey?
            </h2>
            <p className="text-xl mb-8">
              Get in touch with our team today.
            </p>
            <a
              href="/contact"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-primary bg-white hover:bg-gray-50 transition-colors duration-300"
            >
              Contact Us
            </a>
          </div>
        </div>


      </div>
    </div>
  );
}
