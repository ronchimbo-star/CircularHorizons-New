import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import Consultancy from "@/components/sections/consultancy";
import GreenRegistry from "@/components/sections/green-registry";
import ESGReport from "@/components/sections/esg-report";
import MizanESG from "@/components/sections/mizan-esg";

import DynamicSection from "@/components/sections/dynamic-section";

export default function Home() {
  return (
    <div>
      {/* Dynamic Sections - each section is backend-controlled */}
      <DynamicSection sectionName="hero" />
      <DynamicSection sectionName="consultancy" fallbackComponent={Consultancy} />
      <DynamicSection sectionName="green-registry" fallbackComponent={GreenRegistry} />
      <DynamicSection sectionName="esg-report" fallbackComponent={ESGReport} />
      <DynamicSection sectionName="mizan-esg" fallbackComponent={MizanESG} />

      
      {/* CTA Section */}
      <section className="bg-primary">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to accelerate your sustainability journey?</span>
            <span className="block text-accent">Get in touch with our team today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <Link href="/contact">
                <Button className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-primary bg-white hover:bg-gray-50">
                  Contact Us
                </Button>
              </Link>
            </div>
            <div className="ml-3 inline-flex rounded-md shadow">
              <Link href="/contact">
                <Button className="inline-flex items-center justify-center px-5 py-3 border-2 border-white text-base font-medium rounded-md text-white bg-transparent hover:bg-white hover:text-primary transition-all duration-200">
                  Book a Demo
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
