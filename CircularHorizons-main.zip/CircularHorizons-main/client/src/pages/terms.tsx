import DynamicPage from "@/components/dynamic-page";

export default function Terms() {
  return <DynamicPage pageName="terms" />;
}