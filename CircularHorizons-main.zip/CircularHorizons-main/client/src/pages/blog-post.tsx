import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, User, ArrowLeft, Share2, Twitter, Facebook, Linkedin, Copy } from "lucide-react";
import { format } from "date-fns";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export default function BlogPost() {
  const { slug } = useParams();
  const { toast } = useToast();

  const { data: post, isLoading, error } = useQuery({
    queryKey: ["/api/blog", slug],
    queryFn: async () => {
      const response = await fetch(`/api/blog/${slug}`);
      if (!response.ok) {
        throw new Error("Failed to fetch blog post");
      }
      return response.json();
    },
  });

  // Update meta tags for social sharing
  useEffect(() => {
    if (post) {
      const title = post.metaTitle || post.title;
      const description = post.metaDescription || post.excerpt;
      const imageUrl = post.featuredImage;
      const pageUrl = window.location.href;

      // Update document title
      document.title = `${title} | Circular Horizons`;

      // Update or create meta tags
      const updateMetaTag = (name: string, content: string, property?: string) => {
        const selector = property ? `meta[property="${property}"]` : `meta[name="${name}"]`;
        let metaTag = document.querySelector(selector) as HTMLMetaElement;
        
        if (!metaTag) {
          metaTag = document.createElement('meta');
          if (property) {
            metaTag.setAttribute('property', property);
          } else {
            metaTag.setAttribute('name', name);
          }
          document.head.appendChild(metaTag);
        }
        metaTag.setAttribute('content', content);
      };

      // Standard meta tags
      updateMetaTag('description', description);
      updateMetaTag('keywords', post.metaKeywords || post.tags?.join(', ') || '');

      // Open Graph meta tags
      updateMetaTag('', title, 'og:title');
      updateMetaTag('', description, 'og:description');
      updateMetaTag('', 'article', 'og:type');
      updateMetaTag('', pageUrl, 'og:url');
      updateMetaTag('', 'Circular Horizons', 'og:site_name');
      
      if (imageUrl) {
        updateMetaTag('', imageUrl, 'og:image');
        updateMetaTag('', post.imageAlt || title, 'og:image:alt');
      }

      // Twitter Card meta tags
      updateMetaTag('twitter:card', 'summary_large_image');
      updateMetaTag('twitter:title', title);
      updateMetaTag('twitter:description', description);
      if (imageUrl) {
        updateMetaTag('twitter:image', imageUrl);
      }

      // Article specific meta tags
      updateMetaTag('', post.author || 'Ron Chimbo', 'article:author');
      updateMetaTag('', post.createdAt, 'article:published_time');
      updateMetaTag('', post.category, 'article:section');
      
      // Add article tags
      if (post.tags) {
        post.tags.forEach((tag: string) => {
          updateMetaTag('', tag, 'article:tag');
        });
      }
    }

    // Cleanup function to reset title when component unmounts
    return () => {
      document.title = 'Circular Horizons';
    };
  }, [post]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-96 mb-8"></div>
            <div className="h-64 bg-gray-200 rounded mb-8"></div>
            <div className="space-y-3">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
            <p className="text-gray-600 mb-8">The article you're looking for doesn't exist.</p>
            <Link href="/news">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to News
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleShare = async () => {
    const shareData = {
      title: post.metaTitle || post.title,
      text: post.metaDescription || post.excerpt,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        // If sharing fails, fall back to clipboard
        navigator.clipboard.writeText(window.location.href);
      }
    } else {
      // Fallback to clipboard copy
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const handleSocialShare = (platform: string) => {
    const title = encodeURIComponent(post.metaTitle || post.title);
    const description = encodeURIComponent(post.metaDescription || post.excerpt);
    const url = encodeURIComponent(window.location.href);
    const imageUrl = encodeURIComponent(post.featuredImage || '');

    let shareUrl = '';
    
    switch (platform) {
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${title}&url=${url}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
        break;
      default:
        return;
    }

    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "The blog post link has been copied to your clipboard.",
      });
    } catch (error) {
      console.error('Failed to copy link:', error);
      toast({
        title: "Copy failed",
        description: "Unable to copy link to clipboard. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-8">
          <Link href="/news">
            <Button variant="ghost">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to News
            </Button>
          </Link>
        </div>

        {/* Article Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Badge variant="secondary" className="capitalize">
              {post.category}
            </Badge>
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="h-4 w-4 mr-1" />
              {post.createdAt ? format(new Date(post.createdAt), "MMMM d, yyyy") : "No date"}
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <User className="h-4 w-4 mr-1" />
              {post.author}
            </div>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{post.title}</h1>
          
          <p className="text-xl text-gray-600 mb-6">{post.excerpt}</p>
          
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {post.tags.map((tag: string, index: number) => (
                <Badge key={index} variant="outline" className="text-sm">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
          
          <div className="flex items-center gap-4">
            <Button onClick={handleShare} variant="outline">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
            
            {/* Social Media Sharing Buttons */}
            <div className="flex items-center gap-2">
              <Button
                onClick={() => handleSocialShare('twitter')}
                variant="outline"
                size="sm"
                className="text-blue-500 hover:text-blue-600"
              >
                <Twitter className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => handleSocialShare('facebook')}
                variant="outline"
                size="sm"
                className="text-blue-600 hover:text-blue-700"
              >
                <Facebook className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => handleSocialShare('linkedin')}
                variant="outline"
                size="sm"
                className="text-blue-700 hover:text-blue-800"
              >
                <Linkedin className="h-4 w-4" />
              </Button>
              <Button
                onClick={handleCopyLink}
                variant="outline"
                size="sm"
                className="text-gray-600 hover:text-gray-700"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Featured Image */}
        {post.featuredImage && (
          <div className="mb-8">
            <img 
              src={post.featuredImage} 
              alt={post.imageAlt || post.title}
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        )}

        {/* Article Content */}
        <Card>
          <CardContent className="pt-6">
            <div 
              className="prose prose-lg max-w-none"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </CardContent>
        </Card>


      </div>
    </div>
  );
}