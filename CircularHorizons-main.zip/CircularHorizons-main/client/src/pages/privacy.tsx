import DynamicPage from "@/components/dynamic-page";

export default function Privacy() {
  return <DynamicPage pageName="privacy" />;
}