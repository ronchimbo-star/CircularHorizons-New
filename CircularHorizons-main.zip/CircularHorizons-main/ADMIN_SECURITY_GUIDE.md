# Admin Security Configuration Guide

## New Secure Admin Configuration

Your admin system has been upgraded with enhanced security features:

### 🔐 New Admin URL
- **Old URL**: `/admin` (insecure, easily guessable)
- **New URL**: `/management-portal-2024` (obscure, secure)

### 🔑 New Admin Credentials
- **Username**: `circularhorizons_admin`
- **Password**: `CH_Secure_2024!@#`

### 🌐 Access URLs
- **Admin Login**: `https://circularhorizons.com/management-portal-2024/login`
- **Admin Dashboard**: `https://circularhorizons.com/management-portal-2024/dashboard`

## Security Features Implemented

### 1. Obscure Admin URL
- Changed from predictable `/admin` to unique `/management-portal-2024`
- Prevents automated attacks and unauthorized access attempts
- URL is not discoverable through common admin path scanning

### 2. Strong Admin Credentials
- **Strong Username**: `circularhorizons_admin` (company-specific)
- **Strong Password**: `CH_Secure_2024!@#` (12+ characters, mixed case, numbers, symbols)
- Old `admin/admin123` credentials automatically removed

### 3. Automatic Security Upgrade
- System automatically removes old insecure admin account
- Creates new secure admin account on first startup
- Logs security upgrade process

## Deployment Steps

### 1. Update Configuration (Optional)
To change the admin URL or credentials further, edit `server/admin-config.ts`:

```typescript
export const ADMIN_CONFIG = {
  // Change this to your preferred obscure URL
  ADMIN_URL_PATH: "your-custom-admin-path",
  
  // Change these to your preferred credentials
  ADMIN_USERNAME: "your-admin-username",
  ADMIN_PASSWORD: "your-strong-password",
};
```

### 2. Rebuild and Deploy
```bash
npm run build
```

Upload the `dist/` folder to your Hostinger server.

### 3. Restart Application
In Hostinger Node.js Selector:
1. Click "Restart App"
2. Wait for status to show "Running"

### 4. Test New Admin Access
1. Go to: `https://circularhorizons.com/management-portal-2024/login`
2. Login with:
   - Username: `circularhorizons_admin`
   - Password: `CH_Secure_2024!@#`

## Security Best Practices

### 1. Keep Admin URL Secret
- Don't share the admin URL publicly
- Only give access to authorized personnel
- Consider changing the URL periodically

### 2. Use Strong Passwords
- Minimum 12 characters
- Mix of uppercase, lowercase, numbers, symbols
- Avoid common dictionary words
- Change passwords regularly

### 3. Monitor Access
- Check server logs for unauthorized access attempts
- Monitor admin login activity
- Set up alerts for multiple failed login attempts

### 4. Regular Security Updates
- Change admin credentials every 3-6 months
- Update the admin URL if it becomes known
- Keep the system updated with security patches

## Troubleshooting

### Issue: Can't Access Admin Panel
**Solution**: Check the new URL path:
- Correct: `https://circularhorizons.com/management-portal-2024/login`
- Incorrect: `https://circularhorizons.com/admin/login` (old URL)

### Issue: Login Credentials Don't Work
**Solution**: Use new credentials:
- Username: `circularhorizons_admin`
- Password: `CH_Secure_2024!@#`

### Issue: Getting "Not Found" Error
**Solution**: 
1. Ensure the new build is deployed
2. Restart the Node.js application
3. Clear browser cache

## Additional Security Measures

### 1. IP Restrictions (Optional)
Consider adding IP restrictions in `.htaccess`:
```apache
<RequireAll>
  Require ip 192.168.1.100
  Require ip 203.0.113.0/24
</RequireAll>
```

### 2. Two-Factor Authentication
Future enhancement: Add 2FA for additional security

### 3. Session Security
- Sessions expire after 24 hours
- Secure session cookies
- CSRF protection

## Emergency Access

If you're locked out of the admin panel:
1. SSH into your server
2. Edit `server/admin-config.ts`
3. Change credentials to known values
4. Rebuild and deploy
5. Restart the application

## Security Upgrade Log

- **Date**: July 18, 2025
- **Changes**: 
  - Admin URL changed from `/admin` to `/management-portal-2024`
  - Credentials changed from `admin/admin123` to `circularhorizons_admin/CH_Secure_2024!@#`
  - Old admin account automatically removed
  - Security configuration centralized in `server/admin-config.ts`

Your admin system is now significantly more secure with these implementations!