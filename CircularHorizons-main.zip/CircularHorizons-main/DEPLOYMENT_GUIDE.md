# Circular Horizons - Hostinger Deployment Guide

## Prerequisites

- Node.js 18+ installed on your Hostinger hosting
- PostgreSQL database (available through Hostinger's database services)
- SSL certificate (automatic with Hostinger)

## Environment Variables Required

Set these environment variables in your Hostinger control panel:

```bash
# Database Configuration
DATABASE_URL=postgresql://username:password@hostname:port/database_name

# Email Configuration (Gmail SMTP)
EMAIL_USER=ronchimbo@gmail.com
EMAIL_PASS=your-gmail-app-password

# Session Security
SESSION_SECRET=your-secure-random-string-here

# Node Environment
NODE_ENV=production
```

## Build Process

1. **Install Dependencies**
```bash
npm install
```

2. **Build the Application**
```bash
npm run build
```

3. **Database Migration**
```bash
npm run db:push
```

4. **Start Production Server**
```bash
npm start
```

## File Structure for Deployment

```
circular-horizons/
├── dist/                  # Built application files
│   ├── index.js          # Production server bundle
│   └── public/           # Static frontend assets
├── node_modules/         # Dependencies
├── package.json          # Project configuration
├── package-lock.json     # Dependency lock file
└── drizzle.config.ts     # Database configuration
```

## Hostinger Specific Configuration

### 1. Database Setup
- Create a PostgreSQL database in Hostinger control panel
- Note down the connection details (host, port, database name, username, password)
- Use these to construct your DATABASE_URL

### 2. File Upload
Upload these files to your Hostinger public_html directory:
- All files from your project root
- Make sure node_modules is uploaded or run `npm install` on the server

### 3. Environment Variables
In Hostinger control panel:
- Go to "Environment Variables"
- Add all the variables listed above

### 4. Node.js Configuration
- Set Node.js version to 18 or higher
- Set startup file to `dist/index.js`
- Enable automatic restarts

## Post-Deployment Steps

1. **Database Initialization**
```bash
npm run db:push
```

2. **Create Admin Account**
The system will automatically create a default admin account:
- Username: admin
- Password: admin123
- Change this immediately after first login

3. **Test Email Functionality**
- Submit a test contact form
- Verify emails are received at ronchimbo@gmail.com

## Important Security Notes

1. **Change Default Admin Password**
   - Log into admin panel at yoursite.com/admin/login
   - Change the default password immediately

2. **Update SESSION_SECRET**
   - Generate a strong random string
   - Use it as SESSION_SECRET environment variable

3. **SSL Certificate**
   - Ensure SSL is enabled in Hostinger
   - All admin functions require HTTPS

## Available Features

### Public Features
- Homepage with dynamic sections
- About page with team and company information
- Contact form with email delivery
- Blog/news section
- Service pages (Consultancy, ESG Report, etc.)

### Admin Features (yoursite.com/admin)
- Complete site content management
- Blog post creation and management
- Team member management
- Company values and mission editing
- Homepage section customization
- Site settings and branding

## Support

For technical issues:
- Check server logs in Hostinger control panel
- Verify environment variables are set correctly
- Ensure database connection is working
- Test email configuration

## Maintenance

### Regular Updates
- Keep Node.js dependencies updated
- Monitor database performance
- Review and update security settings

### Backup Strategy
- Regular database backups
- Keep local copy of latest code
- Document any customizations