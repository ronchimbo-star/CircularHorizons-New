# Circular Horizons - Export Checklist for Hostinger

## ✅ Pre-Export Verification

### System Status
- [x] Blog management system fully functional
- [x] Admin authentication working
- [x] Contact form sending emails successfully
- [x] About page CMS complete
- [x] Homepage sections management active
- [x] All API endpoints tested and working

### Database Status
- [x] PostgreSQL schema up to date
- [x] All migrations applied
- [x] Sample content populated
- [x] Admin account created (admin/admin123)

## 📁 Files to Upload to Hostinger

### Essential Files (Required)
```
├── dist/                     # Built application
│   ├── index.js             # Server bundle
│   └── public/              # Frontend assets
├── node_modules/            # Dependencies (or run npm install)
├── package.json             # Project configuration
├── package-lock.json        # Dependency versions
├── drizzle.config.ts        # Database configuration
└── .env.example            # Environment template
```

### Optional Files (Recommended)
```
├── DEPLOYMENT_GUIDE.md     # Complete deployment instructions
├── EXPORT_CHECKLIST.md     # This checklist
├── replit.md              # Project documentation
└── README.md              # Project overview
```

## ⚙️ Environment Variables Setup

Copy these to Hostinger environment variables:

```bash
# Database - Replace with your Hostinger PostgreSQL details
DATABASE_URL=postgresql://username:password@hostname:port/database_name

# Email - Use your Gmail credentials
EMAIL_USER=ronchimbo@gmail.com
EMAIL_PASS=your-16-character-gmail-app-password

# Security - Generate a strong random string
SESSION_SECRET=your-secure-random-string-here

# Production setting
NODE_ENV=production
```

## 🗄️ Database Setup Steps

1. **Create PostgreSQL Database in Hostinger**
   - Log into Hostinger control panel
   - Navigate to Databases → Create Database
   - Note the connection details

2. **Run Database Migration**
   ```bash
   npm run db:push
   ```

3. **Verify Tables Created**
   - users (admin accounts)
   - blog_posts (articles)
   - contact_submissions (form data)
   - site_settings (dynamic content)
   - about_founder, about_team, about_values
   - homepage_sections, section_cards
   - page_content

## 🚀 Deployment Steps

### 1. File Transfer
- Upload all files to Hostinger public_html
- Ensure file permissions are correct
- Run `npm install` if node_modules wasn't uploaded

### 2. Environment Configuration
- Set all environment variables in Hostinger panel
- Enable Node.js (version 18+)
- Set startup file to `dist/index.js`

### 3. Database Initialization
```bash
npm run db:push
```

### 4. Start Application
```bash
npm start
```

## 🔧 Post-Deployment Tasks

### Security
- [ ] Change admin password from default (admin123)
- [ ] Verify SSL certificate is active
- [ ] Test all admin functions over HTTPS

### Functionality Testing
- [ ] Test contact form email delivery
- [ ] Verify blog post creation/editing
- [ ] Check about page management
- [ ] Test homepage section editing
- [ ] Confirm site settings updates

### Performance
- [ ] Check page load times
- [ ] Verify database queries are optimized
- [ ] Test with multiple concurrent users

## 📊 Admin Panel Features

### Login: yoursite.com/admin/login
- Username: admin
- Password: admin123 (CHANGE IMMEDIATELY)

### Available Management Areas
- **Dashboard**: Blog post management
- **Settings**: Site branding and contact info
- **Homepage**: Section and card management
- **About**: Team, founder, and values management

## 📧 Email Configuration

### Gmail App Password Setup
1. Enable 2-factor authentication on Gmail
2. Go to Google Account → Security → App passwords
3. Generate password for "Mail" application
4. Use this 16-character password as EMAIL_PASS

## 🆘 Troubleshooting

### Common Issues
- **Database connection**: Check DATABASE_URL format
- **Email not sending**: Verify Gmail app password
- **Admin login fails**: Check SESSION_SECRET is set
- **Static files not loading**: Verify build completed successfully

### Log Locations
- Check Hostinger control panel error logs
- Monitor Node.js application logs
- Review database connection logs

## 📞 Support Information

### Technical Documentation
- See DEPLOYMENT_GUIDE.md for detailed instructions
- Check replit.md for project architecture
- Review package.json for dependency information

### Contact Details
- Email: ronchimbo@gmail.com
- Form submissions automatically sent to above email
- Admin panel accessible at yoursite.com/admin

## ✨ Success Criteria

Deployment is successful when:
- [x] Main site loads without errors
- [x] Admin panel login works
- [x] Contact form sends emails
- [x] Blog posts can be created/edited
- [x] All CMS features functional
- [x] SSL certificate active
- [x] Database queries working