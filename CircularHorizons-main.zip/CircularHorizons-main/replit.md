# Circular Horizons - Sustainability Solutions Platform

## Overview

Circular Horizons is a comprehensive sustainability solutions platform built as a full-stack web application. The platform offers ESG reporting, circular economy consulting, and various sustainability-focused services through a modern React frontend and Express.js backend. The application is designed to help businesses transition to sustainable practices while maintaining profitability.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Email Service**: Nodemailer for contact form submissions
- **Session Management**: Built-in session handling
- **Development**: Hot reload with Vite integration

## Key Components

### Core Services
1. **Consultancy Services**: Strategic planning and circular economy implementation
2. **Green Registry**: Certification and sustainability practice tracking
3. **ESG Reporting**: Comprehensive environmental, social, and governance reporting
4. **Mizan ESG**: Advanced ESG assessment and benchmarking
5. **Waste Institute**: Educational platform for waste management professionals

### Database Schema
- **Users Table**: Basic user management (id, username, password)
- **Contact Submissions**: Form submissions with company details and service interests
- **Site Settings Table**: Key-value store for dynamic site configuration (July 18, 2025)
- **Shared Types**: TypeScript interfaces for type safety across frontend and backend

### Recent Updates - January 17, 2025: Resend Email Integration
- **Contact Form Email Upgrade**: Replaced Nodemailer with Resend for improved email delivery
- **Resend Integration**: Using API key `re_Jq74nZsF_J6X5C9mJdJJhbaRbkzFg65tK` for contact form submissions
- **Email Configuration**: Contact form emails now sent through Resend to ronchimbo@gmail.com
- **Contact Submissions CRUD**: Added delete functionality for spam management in admin panel
- **Cache Updates**: Bumped version to v8-resend-integration for deployment cache refresh

### Previous Updates - July 18, 2025: Complete CMS Implementation with Blog Management
- **Comprehensive Admin Controls**: Full-featured admin interface for site settings management
- **Dynamic Content Integration**: Contact page and components now pull from admin-controlled settings
- **Categorized Settings**: Organized into branding, SEO, social, and contact categories
- **Real-time Updates**: Settings changes reflect immediately across the site without code changes
- **Complete About Page CMS**: Full dynamic management of all about page elements including:
  - **Founder Management**: Complete profile with bio, image, title, and LinkedIn integration
  - **Team Members**: Dynamic team roster with images, bios, titles, and social links
  - **Company Values**: Custom values with both font icons and custom image icons
  - **Display Order Control**: Sortable display order for team members and values
  - **Google Drive Integration**: Automatic URL conversion for Google Drive image links
- **Icon System Enhancement**: Custom icon images display without circular backgrounds while font icons maintain circular styling
- **Card Content Alignment**: All card contents (icons, titles, descriptions, buttons) are now center-aligned
- **Call-to-Action Banner**: Added "Ready to accelerate your sustainability journey?" banner above footer on about page
- **Database Schema**: Extended with dedicated tables for aboutFounder, aboutTeam, and aboutValues
- **API Endpoints**: Complete CRUD operations for all about page elements
- **Fixed Storage Bug**: Resolved variable naming conflict in page content storage method that was causing 500 errors
- **Footer Copyright Management**: Copyright text now editable through admin settings with HTML support
- **Enhanced Admin Security**: Admin URL changed to `/management-portal-2024` with secure credentials `circularhorizons_admin/CH_Secure_2024!@#`
- **Initial Content Population**: Populated all about page sections with sample content including:
  - Ron Chimbo as founder with complete bio and LinkedIn integration
  - Three team members with professional photos and descriptions
  - Company values with appropriate icons and descriptions
  - Page content with professional mission statement
- **Blog Management System**: Fully functional blog creation, editing, and management
  - **Fixed Authentication Issues**: Resolved all API parameter order issues causing authentication failures
  - **Complete Blog CRUD**: Create, read, update, and delete functionality working correctly
  - **Author Field Integration**: Added author field to blog schema and database
  - **SEO Integration**: Full SEO metadata support for blog posts
  - **Publishing Controls**: Draft/published status management
  - **Category Management**: Blog post categorization system
- **Content Cleanup (July 18, 2025)**: Removed all Waste Institute references site-wide
  - **Frontend Cleanup**: Removed component, imports, navbar links, and footer links
  - **Database Cleanup**: Deleted waste institute homepage section and related cards from database
  - **Navigation Update**: Updated navbar and footer to exclude waste institute links
  - **Contact Form Update**: Removed Waste Institute from service selection dropdown
- **CMS Bug Resolution (July 18, 2025)**: Fixed page content management API error
  - **Root Cause**: Complex mutation function causing parameter confusion in fetch calls
  - **Solution**: Simplified mutation to use standard apiRequest pattern matching all other working mutations
  - **Testing**: Verified successful updates to privacy, terms, and cookie policy pages

### UI System
- **Design System**: Custom Tailwind configuration with neutral base colors
- **Primary Colors**: Green (#2c7d3f) for sustainability branding
- **Secondary Colors**: Blue (#1a365d) for professional trust
- **Accent Colors**: Yellow (#ecc94b) for highlighting important elements
- **Component Library**: Comprehensive shadcn/ui components for consistent UX

## Data Flow

### Client-Server Communication
1. **API Requests**: RESTful endpoints with JSON communication
2. **Form Submission**: Contact forms validated with Zod schemas
3. **Email Notifications**: Automated email sending to admin on form submissions
4. **Error Handling**: Centralized error handling with user-friendly messages

### State Management
- **Server State**: TanStack Query for caching and synchronization
- **Form State**: React Hook Form with validation
- **UI State**: React's built-in state management
- **Toast Notifications**: Custom toast system for user feedback

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL for production
- **Drizzle ORM**: Type-safe database operations
- **Connection Pooling**: Built-in connection management

### Email Service
- **Nodemailer**: SMTP email delivery
- **Gmail Integration**: Configured for Gmail SMTP
- **Email Templates**: HTML email formatting for contact submissions

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Static type checking
- **ESLint**: Code quality and consistency
- **Replit Integration**: Development environment support

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React application to `dist/public`
2. **Backend Build**: esbuild bundles Express server to `dist/index.js`
3. **Database Migration**: Drizzle kit manages schema migrations
4. **Asset Optimization**: Vite handles asset bundling and optimization

### Environment Configuration
- **Development**: Hot reload with Vite dev server
- **Production**: Optimized builds with static file serving
- **Database**: Environment-based connection strings
- **Email**: Configuration through environment variables

### Hosting Requirements
- **Node.js**: Runtime environment for Express server
- **PostgreSQL**: Database server (Neon recommended)
- **Static Files**: Served through Express in production
- **Environment Variables**: Database URL, email credentials, and other secrets

The architecture prioritizes developer experience with TypeScript throughout, modern React patterns, and a clean separation between frontend and backend concerns. The platform is designed to scale with additional sustainability services and can easily accommodate new features through its modular component structure.