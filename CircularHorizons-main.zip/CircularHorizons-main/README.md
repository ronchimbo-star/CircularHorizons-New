# Circular Horizons - Sustainability Solutions Platform

A comprehensive full-stack web application for sustainability consultancy, featuring advanced content management and dynamic site administration.

## 🌟 Features

### Public Website
- **Dynamic Homepage**: Fully customizable sections with admin-controlled content
- **About Page**: Team management, founder profiles, and company values
- **Blog System**: Article creation, categorization, and SEO optimization
- **Contact System**: Form submissions with email notifications
- **Service Pages**: Consultancy, ESG reporting, Green Registry, and more

### Admin Panel (`/admin`)
- **Complete CMS**: Full site content management
- **Blog Management**: Create, edit, and publish articles
- **Team Management**: Add/edit team members and founder information
- **Content Control**: Homepage sections, company values, and site settings
- **Email Integration**: Contact form submissions sent to specified email

## 🛠️ Technology Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Radix UI** component library
- **TanStack Query** for state management
- **Wouter** for routing

### Backend
- **Node.js** with Express
- **PostgreSQL** database
- **Drizzle ORM** for database operations
- **Session-based authentication**
- **Nodemailer** for email delivery

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Gmail account for email functionality

### Installation
```bash
npm install
npm run build
npm run db:push
npm start
```

### Environment Variables
```bash
DATABASE_URL=postgresql://username:password@hostname:port/database_name
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-gmail-app-password
SESSION_SECRET=your-secure-random-string
NODE_ENV=production
```

## 📚 Documentation

- **[Deployment Guide](DEPLOYMENT_GUIDE.md)**: Complete Hostinger deployment instructions
- **[Export Checklist](EXPORT_CHECKLIST.md)**: Pre-deployment verification steps
- **[Project Architecture](replit.md)**: Technical documentation and recent changes

## 🔐 Admin Access

Default admin credentials (change immediately):
- Username: `admin`
- Password: `admin123`
- URL: `yoursite.com/admin/login`

## 🎯 Key Accomplishments

- ✅ Complete CMS with granular content control
- ✅ Blog management system with SEO optimization
- ✅ Dynamic about page with team/founder management
- ✅ Email-integrated contact system
- ✅ Responsive design with modern UI components
- ✅ Production-ready build system
- ✅ Secure authentication and session management

## 📞 Support

For technical support or questions:
- Email: ronchimbo@gmail.com
- Contact form submissions are automatically forwarded

## 🏢 About Circular Horizons

Circular Horizons is a sustainability consultancy platform helping businesses transition to sustainable practices while maintaining profitability. We offer comprehensive ESG reporting, circular economy consulting, and various sustainability-focused services.

---

Built with ❤️ for a sustainable future.