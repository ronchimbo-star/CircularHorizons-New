# Hostinger Deployment Troubleshooting

## Issue: "Not Found" Error on Custom Domain

If you're getting a "not found" error on circularhorizons.com, here are the most common causes and solutions:

### 1. Node.js Application Not Running
**Check if Node.js is enabled:**
- Go to Hostinger control panel
- Navigate to "Advanced" → "Node.js Selector"
- Ensure Node.js is enabled for your domain
- Set Node.js version to 18+ or 20+
- Set startup file to `dist/index.js`

### 2. File Structure Issues
**Verify correct file placement:**
```
public_html/
├── dist/
│   ├── index.js          # Must be present
│   └── public/           # Frontend assets
├── package.json
├── node_modules/         # Or run npm install
└── drizzle.config.ts
```

### 3. Environment Variables Missing
**Required environment variables:**
```
DATABASE_URL=postgresql://username:password@hostname:port/database_name
EMAIL_USER=ronchimbo@gmail.com
EMAIL_PASS=your-gmail-app-password
SESSION_SECRET=your-secure-random-string
NODE_ENV=production
PORT=3000
```

### 4. Database Connection Issues
**Check database setup:**
- Verify PostgreSQL database is created
- Test database connection string
- Run migration: `npm run db:push`

### 5. Port Configuration
**Hostinger specific port setup:**
- Add `PORT=3000` environment variable
- Verify Hostinger is routing traffic to correct port

### 6. Domain Configuration
**DNS and domain setup:**
- Verify domain is pointed to correct server
- Check DNS propagation (may take 24-48 hours)
- Ensure SSL certificate is installed

## Quick Fix Steps

### Step 1: Check Node.js Status
```bash
# SSH into your Hostinger server
cd public_html
node --version  # Should show 18+ or 20+
```

### Step 2: Verify Application Structure
```bash
ls -la
# Should show dist/, package.json, node_modules/
ls -la dist/
# Should show index.js and public/
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Test Database Connection
```bash
npm run db:push
```

### Step 5: Start Application
```bash
npm start
```

## Alternative: Manual Start Script

If automatic startup isn't working, create a start script:

```bash
#!/bin/bash
cd /path/to/your/app
export NODE_ENV=production
export DATABASE_URL="your-database-url"
export EMAIL_USER="ronchimbo@gmail.com"
export EMAIL_PASS="your-gmail-app-password"
export SESSION_SECRET="your-secret"
export PORT=3000
node dist/index.js
```

## Common Error Messages and Solutions

### "Cannot find module"
- Run `npm install` in the project directory
- Verify all dependencies are installed

### "Database connection failed"
- Check DATABASE_URL format
- Verify database exists and is accessible
- Run `npm run db:push` to create tables

### "Port already in use"
- Set different PORT environment variable
- Check if another process is using the port

### "Permission denied"
- Check file permissions: `chmod 644 dist/index.js`
- Ensure Node.js has read access to files

## Testing the Deployment

### 1. Test Local Files
```bash
# On your Hostinger server
curl http://localhost:3000
# Should return HTML content
```

### 2. Test Database
```bash
# Check if tables exist
npm run db:push
# Should show "No schema changes detected" if successful
```

### 3. Test API Endpoints
```bash
curl http://localhost:3000/api/site-settings
# Should return JSON with site settings
```

## Contact Support

If these steps don't resolve the issue:
1. Check Hostinger error logs in control panel
2. Verify Node.js application is running
3. Contact Hostinger support with specific error messages
4. Provide details about file structure and environment variables

## Success Indicators

Your deployment is working when:
- circularhorizons.com loads the homepage
- Admin panel accessible at circularhorizons.com/admin
- Contact form sends emails
- All API endpoints respond correctly