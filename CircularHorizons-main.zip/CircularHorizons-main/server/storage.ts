import { 
  users, 
  contactSubmissions, 
  blogPosts, 
  pageContent,
  siteSettings,
  homepageSections,
  sectionCards,
  aboutFounder,
  aboutTeam,
  aboutValues,
  type User, 
  type InsertUser, 
  type ContactSubmission, 
  type InsertContactSubmission,
  type BlogPost,
  type InsertBlogPost,
  type PageContent,
  type InsertPageContent,
  type SiteSetting,
  type InsertSiteSetting,
  type HomepageSection,
  type InsertHomepageSection,
  type SectionCard,
  type InsertSectionCard,
  type AboutFounder,
  type InsertAboutFounder,
  type AboutTeam,
  type InsertAboutTeam,
  type AboutValues,
  type InsertAboutValues,
  aboutSections,
  type AboutSection,
  type InsertAboutSection
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  deleteUser(id: number): Promise<void>;
  
  // Contact submissions
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;
  deleteContactSubmission(id: number): Promise<void>;
  
  // Blog posts
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  getBlogPosts(published?: boolean): Promise<BlogPost[]>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost>;
  deleteBlogPost(id: number): Promise<void>;
  
  // Page content
  createOrUpdatePageContent(content: InsertPageContent): Promise<PageContent>;
  getPageContent(page: string): Promise<PageContent | undefined>;
  getAllPageContent(): Promise<PageContent[]>;
  
  // Site settings
  getSiteSettings(): Promise<SiteSetting[]>;
  getSiteSetting(key: string): Promise<SiteSetting | undefined>;
  upsertSiteSetting(setting: InsertSiteSetting): Promise<SiteSetting>;
  deleteSiteSetting(key: string): Promise<void>;
  
  // Homepage sections
  getHomepageSections(): Promise<HomepageSection[]>;
  getHomepageSection(sectionName: string): Promise<HomepageSection | undefined>;
  upsertHomepageSection(section: InsertHomepageSection): Promise<HomepageSection>;
  updateHomepageSection(id: number, section: Partial<InsertHomepageSection>): Promise<HomepageSection>;
  deleteHomepageSection(id: number): Promise<void>;
  
  // Section cards
  getSectionCards(sectionId: number): Promise<SectionCard[]>;
  createSectionCard(card: InsertSectionCard): Promise<SectionCard>;
  updateSectionCard(id: number, card: Partial<InsertSectionCard>): Promise<SectionCard>;
  deleteSectionCard(id: number): Promise<void>;
  
  // About page elements
  getAboutFounder(): Promise<AboutFounder | undefined>;
  createOrUpdateAboutFounder(founder: InsertAboutFounder): Promise<AboutFounder>;
  getAboutTeam(): Promise<AboutTeam[]>;
  createAboutTeamMember(member: InsertAboutTeam): Promise<AboutTeam>;
  updateAboutTeamMember(id: number, member: Partial<InsertAboutTeam>): Promise<AboutTeam>;
  deleteAboutTeamMember(id: number): Promise<void>;
  getAboutValues(): Promise<AboutValues[]>;
  createAboutValue(value: InsertAboutValues): Promise<AboutValues>;
  updateAboutValue(id: number, value: Partial<InsertAboutValues>): Promise<AboutValues>;
  deleteAboutValue(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Contact submissions
  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const [contactSubmission] = await db
      .insert(contactSubmissions)
      .values({
        ...submission,
        company: submission.company || null,
        service: submission.service || null,
      })
      .returning();
    return contactSubmission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
  }

  async deleteContactSubmission(id: number): Promise<void> {
    await db.delete(contactSubmissions).where(eq(contactSubmissions.id, id));
  }

  // Blog posts
  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [blogPost] = await db
      .insert(blogPosts)
      .values(post)
      .returning();
    return blogPost;
  }

  async getBlogPosts(published?: boolean): Promise<BlogPost[]> {
    const query = db.select().from(blogPosts);
    if (published !== undefined) {
      query.where(eq(blogPosts.published, published));
    }
    return await query.orderBy(desc(blogPosts.createdAt));
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost> {
    const [updatedPost] = await db
      .update(blogPosts)
      .set({ ...post, updatedAt: new Date() })
      .where(eq(blogPosts.id, id))
      .returning();
    return updatedPost;
  }

  async deleteBlogPost(id: number): Promise<void> {
    await db.delete(blogPosts).where(eq(blogPosts.id, id));
  }

  // Page content
  async createOrUpdatePageContent(content: InsertPageContent): Promise<PageContent> {
    const [result] = await db
      .insert(pageContent)
      .values(content)
      .onConflictDoUpdate({
        target: pageContent.page,
        set: {
          title: content.title,
          content: content.content,
          seoTitle: content.seoTitle,
          seoDescription: content.seoDescription,
          seoKeywords: content.seoKeywords,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  async getPageContent(page: string): Promise<PageContent | undefined> {
    const [content] = await db.select().from(pageContent).where(eq(pageContent.page, page));
    return content;
  }

  async getAllPageContent(): Promise<PageContent[]> {
    return await db.select().from(pageContent);
  }

  // Site settings
  async getSiteSettings(): Promise<SiteSetting[]> {
    return await db.select().from(siteSettings);
  }

  async getSiteSetting(key: string): Promise<SiteSetting | undefined> {
    const [setting] = await db.select().from(siteSettings).where(eq(siteSettings.key, key));
    return setting;
  }

  async upsertSiteSetting(setting: InsertSiteSetting): Promise<SiteSetting> {
    const [siteSetting] = await db
      .insert(siteSettings)
      .values(setting)
      .onConflictDoUpdate({
        target: siteSettings.key,
        set: {
          value: setting.value,
          type: setting.type,
          category: setting.category,
          description: setting.description,
          updatedAt: new Date(),
        },
      })
      .returning();
    return siteSetting;
  }

  async deleteSiteSetting(key: string): Promise<void> {
    await db.delete(siteSettings).where(eq(siteSettings.key, key));
  }

  // Homepage sections
  async getHomepageSections(): Promise<HomepageSection[]> {
    return await db.select().from(homepageSections).orderBy(homepageSections.sortOrder);
  }

  async getHomepageSection(sectionName: string): Promise<HomepageSection | undefined> {
    const [section] = await db.select().from(homepageSections).where(eq(homepageSections.sectionName, sectionName));
    return section;
  }

  async upsertHomepageSection(section: InsertHomepageSection): Promise<HomepageSection> {
    const [homepageSection] = await db
      .insert(homepageSections)
      .values(section)
      .onConflictDoUpdate({
        target: homepageSections.sectionName,
        set: {
          title: section.title,
          subtitle: section.subtitle,
          description: section.description,
          backgroundImage: section.backgroundImage,
          backgroundColor: section.backgroundColor,
          textColor: section.textColor,
          overlayText: section.overlayText,
          buttonText: section.buttonText,
          buttonLink: section.buttonLink,
          icon: section.icon,
          isVisible: section.isVisible,
          sortOrder: section.sortOrder,
          updatedAt: new Date(),
        },
      })
      .returning();
    return homepageSection;
  }

  async updateHomepageSection(id: number, section: Partial<InsertHomepageSection>): Promise<HomepageSection> {
    const [homepageSection] = await db
      .update(homepageSections)
      .set({
        ...section,
        updatedAt: new Date(),
      })
      .where(eq(homepageSections.id, id))
      .returning();
    return homepageSection;
  }

  async deleteHomepageSection(id: number): Promise<void> {
    await db.delete(homepageSections).where(eq(homepageSections.id, id));
  }

  // Section cards
  async getSectionCards(sectionId: number): Promise<SectionCard[]> {
    return await db.select().from(sectionCards).where(eq(sectionCards.sectionId, sectionId)).orderBy(sectionCards.sortOrder);
  }

  async createSectionCard(card: InsertSectionCard): Promise<SectionCard> {
    const [sectionCard] = await db
      .insert(sectionCards)
      .values(card)
      .returning();
    return sectionCard;
  }

  async updateSectionCard(id: number, card: Partial<InsertSectionCard>): Promise<SectionCard> {
    const [sectionCard] = await db
      .update(sectionCards)
      .set(card)
      .where(eq(sectionCards.id, id))
      .returning();
    return sectionCard;
  }

  async deleteSectionCard(id: number): Promise<void> {
    await db.delete(sectionCards).where(eq(sectionCards.id, id));
  }

  // About page elements
  async getAboutFounder(): Promise<AboutFounder | undefined> {
    const [founder] = await db.select().from(aboutFounder).limit(1);
    return founder;
  }

  async createOrUpdateAboutFounder(founder: InsertAboutFounder): Promise<AboutFounder> {
    const existing = await this.getAboutFounder();
    if (existing) {
      const [updated] = await db
        .update(aboutFounder)
        .set({ ...founder, updatedAt: new Date() })
        .where(eq(aboutFounder.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(aboutFounder)
        .values(founder)
        .returning();
      return created;
    }
  }

  async getAboutTeam(): Promise<AboutTeam[]> {
    return await db.select().from(aboutTeam).orderBy(aboutTeam.order);
  }

  async createAboutTeamMember(member: InsertAboutTeam): Promise<AboutTeam> {
    const [created] = await db
      .insert(aboutTeam)
      .values(member)
      .returning();
    return created;
  }

  async updateAboutTeamMember(id: number, member: Partial<InsertAboutTeam>): Promise<AboutTeam> {
    const [updated] = await db
      .update(aboutTeam)
      .set({ ...member, updatedAt: new Date() })
      .where(eq(aboutTeam.id, id))
      .returning();
    return updated;
  }

  async deleteAboutTeamMember(id: number): Promise<void> {
    await db.delete(aboutTeam).where(eq(aboutTeam.id, id));
  }

  async getAboutValues(): Promise<AboutValues[]> {
    return await db.select().from(aboutValues).orderBy(aboutValues.order);
  }

  async createAboutValue(value: InsertAboutValues): Promise<AboutValues> {
    const [created] = await db
      .insert(aboutValues)
      .values(value)
      .returning();
    return created;
  }

  async updateAboutValue(id: number, value: Partial<InsertAboutValues>): Promise<AboutValues> {
    const [updated] = await db
      .update(aboutValues)
      .set({ ...value, updatedAt: new Date() })
      .where(eq(aboutValues.id, id))
      .returning();
    return updated;
  }

  async deleteAboutValue(id: number): Promise<void> {
    await db.delete(aboutValues).where(eq(aboutValues.id, id));
  }

  // About sections operations
  async getAboutSections(): Promise<AboutSection[]> {
    return await db.select().from(aboutSections).where(eq(aboutSections.isActive, true)).orderBy(aboutSections.displayOrder);
  }

  async getAboutSection(sectionKey: string): Promise<AboutSection | null> {
    const [section] = await db.select().from(aboutSections).where(eq(aboutSections.sectionKey, sectionKey)).limit(1);
    return section || null;
  }

  async upsertAboutSection(data: InsertAboutSection): Promise<AboutSection> {
    const [section] = await db.insert(aboutSections)
      .values(data)
      .onConflictDoUpdate({
        target: aboutSections.sectionKey,
        set: { ...data, updatedAt: new Date() }
      })
      .returning();
    return section;
  }

  async updateAboutSection(sectionKey: string, data: Partial<InsertAboutSection>): Promise<AboutSection> {
    const [section] = await db.update(aboutSections)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(aboutSections.sectionKey, sectionKey))
      .returning();
    return section;
  }

  async deleteAboutSection(sectionKey: string): Promise<void> {
    await db.delete(aboutSections).where(eq(aboutSections.sectionKey, sectionKey));
  }
}

export const storage = new DatabaseStorage();
