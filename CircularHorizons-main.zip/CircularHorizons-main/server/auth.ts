import { Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import session from "express-session";
import { ADMIN_CONFIG } from "./admin-config";

declare module "express-session" {
  interface SessionData {
    userId?: number;
    userRole?: string;
  }
}

export async function createDefaultAdmin() {
  try {
    // Check if admin exists with new username
    const existingAdmin = await storage.getUserByUsername(ADMIN_CONFIG.ADMIN_USERNAME);
    if (!existingAdmin) {
      // Check if old admin exists and delete it
      const oldAdmin = await storage.getUserByUsername("admin");
      if (oldAdmin) {
        await storage.deleteUser(oldAdmin.id);
        console.log("Old admin account removed for security");
      }
      
      // Create new admin account with secure credentials
      const hashedPassword = await bcrypt.hash(ADMIN_CONFIG.ADMIN_PASSWORD, 10);
      await storage.createUser({
        username: ADMIN_CONFIG.ADMIN_USERNAME,
        password: hashedPassword,
        role: "admin"
      });
      console.log(`Secure admin account created: ${ADMIN_CONFIG.ADMIN_USERNAME}`);
      console.log(`Admin panel URL: /${ADMIN_CONFIG.ADMIN_URL_PATH}/login`);
    }
  } catch (error) {
    console.error("Error creating default admin:", error);
  }
}

export async function login(username: string, password: string) {
  const user = await storage.getUserByUsername(username);
  if (!user) {
    throw new Error("Invalid credentials");
  }
  
  const isValid = await bcrypt.compare(password, user.password);
  if (!isValid) {
    throw new Error("Invalid credentials");
  }
  
  return user;
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  // Check for auth token in header
  const authToken = req.headers.authorization?.replace('Bearer ', '');
  
  if (!authToken) {
    return res.status(401).json({ error: "No auth token provided" });
  }
  
  try {
    // Decode the auth token
    const decoded = Buffer.from(authToken, 'base64').toString('ascii');
    const [userId, username, role] = decoded.split(':');
    
    if (role !== 'admin') {
      return res.status(401).json({ error: "Admin access required" });
    }
    
    // Store user info in request for use in route handlers
    (req as any).user = { id: parseInt(userId), username, role };
    next();
  } catch (decodeError) {
    return res.status(401).json({ error: "Invalid auth token format" });
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  console.log("Auth check - Session data:", { 
    sessionId: req.sessionID, 
    userId: req.session.userId, 
    userRole: req.session.userRole,
    hasSession: !!req.session 
  });
  
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}