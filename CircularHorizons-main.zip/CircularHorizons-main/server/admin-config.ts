// Admin configuration - Change these values for security
export const ADMIN_CONFIG = {
  // Change this to an obscure URL path (no leading slash)
  ADMIN_URL_PATH: "management-portal-2024",
  
  // Change these credentials for security
  ADMIN_USERNAME: "circularhorizons_admin",
  ADMIN_PASSWORD: "CH_Secure_2024!@#",
  
  // Session configuration
  SESSION_SECRET: process.env.SESSION_SECRET || "your-super-secret-session-key-change-me",
  SESSION_MAX_AGE: 24 * 60 * 60 * 1000, // 24 hours
};

// Don't expose these in logs
export function getObscuredConfig() {
  return {
    ADMIN_URL_PATH: ADMIN_CONFIG.ADMIN_URL_PATH,
    ADMIN_USERNAME: ADMIN_CONFIG.ADMIN_USERNAME,
    ADMIN_PASSWORD: "***HIDDEN***",
  };
}