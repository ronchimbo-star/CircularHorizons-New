import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema, insertBlogPostSchema, insertPageContentSchema, insertHomepageSectionSchema, insertSectionCardSchema, insertAboutFounderSchema, insertAboutTeamSchema, insertAboutValuesSchema } from "@shared/schema";
import { z } from "zod";
import { Resend } from 'resend';
import session from "express-session";
import MemoryStore from "memorystore";
import { createDefaultAdmin, login, requireAdmin, requireAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Session middleware with memory store
  const MemoryStoreSession = MemoryStore(session);
  
  app.use(session({
    secret: process.env.SESSION_SECRET || 'circular-horizons-secret-key-for-development',
    resave: true, // Force session save even if not modified
    saveUninitialized: false,
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      secure: false, // Set to false for development
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24, // 24 hours
      sameSite: 'lax',
      domain: undefined // Let browser handle domain
    },
    name: 'connect.sid' // Explicitly set session name
  }));

  // Add debugging middleware to log all session info
  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url} - Session ID: ${req.sessionID}, User: ${req.session.userId}`);
    next();
  });

  // Create default admin account
  await createDefaultAdmin();
  
  // Initialize Resend for email sending
  const resend = new Resend('re_Jq74nZsF_J6X5C9mJdJJhbaRbkzFg65tK');

  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      
      // Store in database
      const submission = await storage.createContactSubmission(validatedData);
      
      // Send email to admin using Resend
      await resend.emails.send({
        from: 'onboarding@resend.dev',
        to: 'ronchimbo@gmail.com',
        subject: `New Contact Form Submission - ${validatedData.name}`,
        html: `
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${validatedData.name}</p>
          <p><strong>Email:</strong> ${validatedData.email}</p>
          <p><strong>Company:</strong> ${validatedData.company || 'Not provided'}</p>
          <p><strong>Service of Interest:</strong> ${validatedData.service || 'Not specified'}</p>
          <p><strong>Message:</strong></p>
          <p>${validatedData.message}</p>
          <hr>
          <p><em>This message was sent from the Circular Horizons website contact form.</em></p>
        `
      });
      
      res.json({ success: true, message: "Thank you for your message! We'll get back to you within 24 hours." });
    } catch (error) {
      console.error("Contact form error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid form data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to send message. Please try again later." });
      }
    }
  });

  // Authentication routes - using simple token-based auth
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await login(username, password);
      
      // Generate a simple auth token (in production, use JWT)
      const authToken = Buffer.from(`${user.id}:${user.username}:${user.role}:${Date.now()}`).toString('base64');
      
      // Set session data for server-side validation
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.authToken = authToken;
      
      console.log("User logged in:", { 
        sessionId: req.sessionID,
        userId: user.id, 
        userRole: user.role,
        authToken: authToken.substring(0, 20) + "..."
      });
      
      res.json({ 
        user: { id: user.id, username: user.username, role: user.role },
        authToken: authToken
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Check current auth status
  app.get("/api/auth/me", async (req, res) => {
    try {
      // Check for auth token in header
      const authToken = req.headers.authorization?.replace('Bearer ', '');
      
      if (!authToken) {
        return res.status(401).json({ error: "No auth token provided" });
      }
      
      try {
        // Decode the auth token
        const decoded = Buffer.from(authToken, 'base64').toString('ascii');
        const [userId, username, role] = decoded.split(':');
        
        // Validate token by checking if user exists
        const user = await storage.getUser(parseInt(userId));
        if (!user || user.username !== username || user.role !== role) {
          return res.status(401).json({ error: "Invalid auth token" });
        }
        
        res.json({ user: { id: user.id, username: user.username, role: user.role } });
      } catch (decodeError) {
        return res.status(401).json({ error: "Invalid auth token format" });
      }
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ error: "Failed to verify authentication" });
    }
  });

  // Blog routes
  app.get("/api/blog", async (req, res) => {
    try {
      const published = req.query.published === "true";
      const posts = await storage.getBlogPosts(published);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/blog/:slug", async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ error: "Failed to fetch blog post" });
    }
  });

  // Admin routes
  app.get("/api/admin/blog", requireAdmin, async (req, res) => {
    try {
      const posts = await storage.getBlogPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  app.post("/api/admin/blog", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertBlogPostSchema.parse(req.body);
      const post = await storage.createBlogPost(validatedData);
      res.json(post);
    } catch (error) {
      console.error("Error creating blog post:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create blog post" });
      }
    }
  });

  app.get("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      const post = await storage.getBlogPost(parseInt(req.params.id));
      if (!post) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ error: "Failed to fetch blog post" });
    }
  });

  app.put("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertBlogPostSchema.partial().parse(req.body);
      const post = await storage.updateBlogPost(parseInt(req.params.id), validatedData);
      res.json(post);
    } catch (error) {
      console.error("Error updating blog post:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update blog post" });
      }
    }
  });

  app.delete("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      await storage.deleteBlogPost(parseInt(req.params.id));
      res.json({ message: "Blog post deleted" });
    } catch (error) {
      console.error("Error deleting blog post:", error);
      res.status(500).json({ error: "Failed to delete blog post" });
    }
  });

  // Page content routes
  app.get("/api/page-content/:page", async (req, res) => {
    try {
      const content = await storage.getPageContent(req.params.page);
      res.json(content);
    } catch (error) {
      console.error("Error fetching page content:", error);
      res.status(500).json({ error: "Failed to fetch page content" });
    }
  });

  app.post("/api/admin/page-content", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertPageContentSchema.parse(req.body);
      const content = await storage.createOrUpdatePageContent(validatedData);
      res.json(content);
    } catch (error) {
      console.error("Error updating page content:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update page content" });
      }
    }
  });

  app.get("/api/admin/page-content", requireAdmin, async (req, res) => {
    try {
      const content = await storage.getAllPageContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching page content:", error);
      res.status(500).json({ error: "Failed to fetch page content" });
    }
  });

  // Get all contact submissions (for admin use)
  app.get("/api/admin/contact-submissions", requireAdmin, async (req, res) => {
    try {
      const submissions = await storage.getContactSubmissions();
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching contact submissions:", error);
      res.status(500).json({ error: "Failed to fetch submissions" });
    }
  });

  app.delete("/api/admin/contact-submissions/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid ID" });
      }
      
      await storage.deleteContactSubmission(id);
      res.json({ message: "Contact submission deleted successfully" });
    } catch (error) {
      console.error("Error deleting contact submission:", error);
      res.status(500).json({ error: "Failed to delete contact submission" });
    }
  });

  // About page elements routes
  // About founder
  app.get("/api/about/founder", async (req, res) => {
    try {
      const founder = await storage.getAboutFounder();
      res.json(founder);
    } catch (error) {
      console.error("Error fetching about founder:", error);
      res.status(500).json({ error: "Failed to fetch about founder" });
    }
  });

  app.post("/api/admin/about/founder", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertAboutFounderSchema.parse(req.body);
      const founder = await storage.createOrUpdateAboutFounder(validatedData);
      res.json(founder);
    } catch (error) {
      console.error("Error updating about founder:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update about founder" });
      }
    }
  });

  // About team
  app.get("/api/about/team", async (req, res) => {
    try {
      const team = await storage.getAboutTeam();
      res.json(team);
    } catch (error) {
      console.error("Error fetching about team:", error);
      res.status(500).json({ error: "Failed to fetch about team" });
    }
  });

  app.post("/api/admin/about/team", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertAboutTeamSchema.parse(req.body);
      const member = await storage.createAboutTeamMember(validatedData);
      res.json(member);
    } catch (error) {
      console.error("Error creating team member:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create team member" });
      }
    }
  });

  app.put("/api/admin/about/team/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertAboutTeamSchema.partial().parse(req.body);
      const member = await storage.updateAboutTeamMember(parseInt(req.params.id), validatedData);
      res.json(member);
    } catch (error) {
      console.error("Error updating team member:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update team member" });
      }
    }
  });

  app.delete("/api/admin/about/team/:id", requireAdmin, async (req, res) => {
    try {
      await storage.deleteAboutTeamMember(parseInt(req.params.id));
      res.json({ message: "Team member deleted" });
    } catch (error) {
      console.error("Error deleting team member:", error);
      res.status(500).json({ error: "Failed to delete team member" });
    }
  });

  // About values
  app.get("/api/about/values", async (req, res) => {
    try {
      const values = await storage.getAboutValues();
      res.json(values);
    } catch (error) {
      console.error("Error fetching about values:", error);
      res.status(500).json({ error: "Failed to fetch about values" });
    }
  });

  app.post("/api/admin/about/values", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertAboutValuesSchema.parse(req.body);
      const value = await storage.createAboutValue(validatedData);
      res.json(value);
    } catch (error) {
      console.error("Error creating about value:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create about value" });
      }
    }
  });

  app.put("/api/admin/about/values/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertAboutValuesSchema.partial().parse(req.body);
      const value = await storage.updateAboutValue(parseInt(req.params.id), validatedData);
      res.json(value);
    } catch (error) {
      console.error("Error updating about value:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update about value" });
      }
    }
  });

  app.delete("/api/admin/about/values/:id", requireAdmin, async (req, res) => {
    try {
      await storage.deleteAboutValue(parseInt(req.params.id));
      res.json({ message: "About value deleted" });
    } catch (error) {
      console.error("Error deleting about value:", error);
      res.status(500).json({ error: "Failed to delete about value" });
    }
  });

  // About sections API routes
  app.get("/api/about/sections", async (req, res) => {
    try {
      const sections = await storage.getAboutSections();
      res.json(sections);
    } catch (error) {
      console.error("Error fetching about sections:", error);
      res.status(500).json({ error: "Failed to fetch about sections" });
    }
  });

  app.get("/api/about/sections/:sectionKey", async (req, res) => {
    try {
      const section = await storage.getAboutSection(req.params.sectionKey);
      res.json(section);
    } catch (error) {
      console.error("Error fetching about section:", error);
      res.status(500).json({ error: "Failed to fetch about section" });
    }
  });

  app.post("/api/admin/about/sections", requireAdmin, async (req, res) => {
    try {
      const section = await storage.upsertAboutSection(req.body);
      res.json(section);
    } catch (error) {
      console.error("Error upserting about section:", error);
      res.status(500).json({ error: "Failed to upsert about section" });
    }
  });

  app.put("/api/admin/about/sections/:sectionKey", requireAdmin, async (req, res) => {
    try {
      const section = await storage.updateAboutSection(req.params.sectionKey, req.body);
      res.json(section);
    } catch (error) {
      console.error("Error updating about section:", error);
      res.status(500).json({ error: "Failed to update about section" });
    }
  });

  app.delete("/api/admin/about/sections/:sectionKey", requireAdmin, async (req, res) => {
    try {
      await storage.deleteAboutSection(req.params.sectionKey);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting about section:", error);
      res.status(500).json({ error: "Failed to delete about section" });
    }
  });

  // Site settings routes
  app.get("/api/site-settings", async (req, res) => {
    try {
      const settings = await storage.getSiteSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching site settings:", error);
      res.status(500).json({ error: "Failed to fetch site settings" });
    }
  });

  app.get("/api/site-settings/:key", async (req, res) => {
    try {
      const { key } = req.params;
      const setting = await storage.getSiteSetting(key);
      if (!setting) {
        return res.status(404).json({ error: "Site setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error fetching site setting:", error);
      res.status(500).json({ error: "Failed to fetch site setting" });
    }
  });

  app.post("/api/admin/site-settings", requireAdmin, async (req, res) => {
    try {
      const setting = await storage.upsertSiteSetting(req.body);
      res.json(setting);
    } catch (error) {
      console.error("Error saving site setting:", error);
      res.status(500).json({ error: "Failed to save site setting" });
    }
  });

  app.delete("/api/admin/site-settings/:key", requireAdmin, async (req, res) => {
    try {
      const { key } = req.params;
      await storage.deleteSiteSetting(key);
      res.json({ message: "Site setting deleted successfully" });
    } catch (error) {
      console.error("Error deleting site setting:", error);
      res.status(500).json({ error: "Failed to delete site setting" });
    }
  });

  // Homepage sections routes
  app.get("/api/homepage-sections", async (req, res) => {
    try {
      const sections = await storage.getHomepageSections();
      res.json(sections);
    } catch (error) {
      console.error("Error fetching homepage sections:", error);
      res.status(500).json({ error: "Failed to fetch homepage sections" });
    }
  });

  app.get("/api/homepage-sections/:sectionName", async (req, res) => {
    try {
      const { sectionName } = req.params;
      const section = await storage.getHomepageSection(sectionName);
      if (!section) {
        return res.status(404).json({ error: "Homepage section not found" });
      }
      res.json(section);
    } catch (error) {
      console.error("Error fetching homepage section:", error);
      res.status(500).json({ error: "Failed to fetch homepage section" });
    }
  });

  app.post("/api/admin/homepage-sections", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertHomepageSectionSchema.parse(req.body);
      const section = await storage.upsertHomepageSection(validatedData);
      res.json(section);
    } catch (error) {
      console.error("Error saving homepage section:", error);
      res.status(500).json({ error: "Failed to save homepage section" });
    }
  });

  app.put("/api/admin/homepage-sections/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertHomepageSectionSchema.parse(req.body);
      const section = await storage.updateHomepageSection(parseInt(id), validatedData);
      if (!section) {
        return res.status(404).json({ error: "Homepage section not found" });
      }
      res.json(section);
    } catch (error) {
      console.error("Error updating homepage section:", error);
      res.status(500).json({ error: "Failed to update homepage section" });
    }
  });

  app.delete("/api/admin/homepage-sections/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteHomepageSection(parseInt(id));
      res.json({ message: "Homepage section deleted successfully" });
    } catch (error) {
      console.error("Error deleting homepage section:", error);
      res.status(500).json({ error: "Failed to delete homepage section" });
    }
  });

  // Section cards routes
  app.get("/api/section-cards/:sectionId", async (req, res) => {
    try {
      const { sectionId } = req.params;
      const cards = await storage.getSectionCards(parseInt(sectionId));
      res.json(cards);
    } catch (error) {
      console.error("Error fetching section cards:", error);
      res.status(500).json({ error: "Failed to fetch section cards" });
    }
  });

  app.post("/api/admin/section-cards", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertSectionCardSchema.parse(req.body);
      const card = await storage.createSectionCard(validatedData);
      res.json(card);
    } catch (error) {
      console.error("Error creating section card:", error);
      res.status(500).json({ error: "Failed to create section card" });
    }
  });

  app.put("/api/admin/section-cards/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertSectionCardSchema.parse(req.body);
      const card = await storage.updateSectionCard(parseInt(id), validatedData);
      if (!card) {
        return res.status(404).json({ error: "Section card not found" });
      }
      res.json(card);
    } catch (error) {
      console.error("Error updating section card:", error);
      res.status(500).json({ error: "Failed to update section card" });
    }
  });

  app.delete("/api/admin/section-cards/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteSectionCard(parseInt(id));
      res.json({ message: "Section card deleted successfully" });
    } catch (error) {
      console.error("Error deleting section card:", error);
      res.status(500).json({ error: "Failed to delete section card" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
